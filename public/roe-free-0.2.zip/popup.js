// Roe popup. Everything from the page is rendered with textContent only, never innerHTML,
// so a hostile page cannot inject markup into this UI.
const app = document.getElementById('app');
const el = (tag, cls, text) => {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (text !== undefined) n.textContent = text;
  return n;
};
const LEVEL = { high: 'High risk', medium: 'Medium risk', low: 'Weak signal' };
const RANK = { high: 0, medium: 1, low: 2 };
let tabId = null;
let filter = 'all';
const { CATS, REFS } = Roe;

const wait = (ms) => new Promise((r) => setTimeout(r, ms));
const fetchReport = () => chrome.runtime.sendMessage({ type: 'roe:get', tabId });

async function load() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) return;
  tabId = tab.id;
  const settings = await chrome.storage.local.get({ mode: 'warn', allow: [], ghRaw: true, scanImages: true, scanDownloads: true, downloadScans: [] });
  let data = (await fetchReport()) || { frames: {} };

  // Tabs that were already open when Roe was installed or reloaded never got the content
  // script. Inject it now (allowed by activeTab because the person just opened the popup).
  if (!data.frames[0]) {
    try {
      await chrome.scripting.executeScript({
        target: { tabId, allFrames: true },
        files: ['detector.js', 'sinks.js', 'surfaces.js', 'content.js']
      });
    } catch (e) { /* browser pages, the Web Store and PDFs cannot be scripted */ }
    for (let i = 0; i < 8 && !data.frames[0]; i++) {
      await wait(400);
      data = (await fetchReport()) || { frames: {} };
    }
  }
  render(settings, data);
}

const SURFACE_NOTE = {
  email: 'Email bodies are written by strangers and are read by mail agents.',
  github: 'Issues, PRs and READMEs are written by anyone and are read by coding agents.',
  raw: 'Raw files are loaded by agents as-is.',
  chat: 'Chat messages come from other people and bots.',
  tickets: 'Tickets are written by customers and outsiders.',
  docs: 'Shared documents can be edited by others.',
  social: 'Public posts are open to anyone.',
  file: 'A local file.',
  web: 'Any public page can carry hidden text.'
};

function link(ref) {
  const a = el('a', '', ref.name);
  if (ref.url) { a.href = ref.url; a.target = '_blank'; a.rel = 'noreferrer noopener'; }
  return a;
}

function render(settings, data) {
  app.replaceChildren();
  const frames = Object.entries(data.frames);
  const top = data.frames[0];

  if (!top) {
    const v = el('div', 'verdict');
    v.append(el('h2', '', 'Roe has not scanned this tab'),
      el('p', '', 'It cannot run on browser pages, the Web Store or PDFs. For local files, turn on \u201CAllow access to file URLs\u201D for Roe in chrome://extensions. On a normal page, try reloading it.'));
    app.append(v);
    return;
  }

  const host = new URL(top.url).hostname || 'this page';
  const paused = settings.allow.includes(host);
  const surf = top.surface || { id: 'web', label: 'Public web page' };

  const findings = [];
  const sinkList = [];
  for (const [frameId, rep] of frames) {
    for (const f of rep.findings) findings.push({ ...f, frameId: Number(frameId) });
    sinkList.push(...(rep.sinks || []));
  }
  findings.sort((a, b) => RANK[a.level] - RANK[b.level] || Number(b.hidden) - Number(a.hidden));
  const live = findings.filter((f) => !f.gone && !f.sanitized);
  const strong = findings.filter((f) => f.level !== 'low');
  const activeStrong = strong.filter((f) => !f.sanitized && !f.gone);
  const weak = findings.filter((f) => f.level === 'low');
  const hiddenCount = strong.filter((f) => f.hidden).length;
  const removedCount = findings.filter((f) => f.sanitized || f.gone).length;
  const removableHidden = strong.filter((f) => f.hidden && f.removable && !f.sanitized && !f.gone);

  // surface chip
  const chip = el('div', 'surface');
  chip.append(el('span', 'chip', surf.label), el('span', 'host', host));
  app.append(chip, el('p', 'surfnote', SURFACE_NOTE[surf.id] || SURFACE_NOTE.web));

  // verdict
  const v = el('div', 'verdict ' + (paused ? '' : activeStrong.length ? 'bad' : 'ok'));
  if (paused) {
    v.append(el('h2', '', 'Roe is paused on ' + host), el('p', '', 'Nothing on this site is being scanned or changed.'));
  } else if (activeStrong.length) {
    const anth = activeStrong.filter((f) => f.anthropic).length;
    const nHidden = activeStrong.filter((f) => f.hidden).length;
    v.append(
      el('h2', '', activeStrong.length + (activeStrong.length === 1 ? ' possible attack on an AI agent found' : ' possible attacks on an AI agent found')),
      el('p', '', (nHidden ? nHidden + ' of ' + activeStrong.length + ' are hidden from you but readable by an agent.' : 'They are visible on the page.') +
        (removedCount ? ' ' + removedCount + ' removed from the page.' : '') +
        (anth ? ' ' + anth + ' match attacks Anthropic has written about.' : ''))
    );
  } else {
    v.append(el('h2', '', removedCount ? removedCount + ' hidden item' + (removedCount === 1 ? '' : 's') + ' removed from this page' : 'No attack signals found'),
      el('p', '', removedCount ? 'The text is gone from the page DOM. Roe keeps the evidence below so you can still copy it.' : 'Roe matches known patterns only, so this does not prove the page is safe.'));
  }
  app.append(v);

  // controls
  const controls = el('div', 'controls');
  const seg = el('div', 'seg');
  seg.setAttribute('role', 'group');
  seg.setAttribute('aria-label', 'What Roe does with hidden text');
  [['warn', 'Warn only'], ['sanitize', 'Warn and remove hidden text']].forEach(([mode, label]) => {
    const b = el('button', '', label);
    b.setAttribute('aria-pressed', String(settings.mode === mode));
    b.addEventListener('click', async () => { await chrome.storage.local.set({ mode }); setTimeout(load, 800); });
    seg.append(b);
  });
  const site = el('button', 'link', paused ? 'Resume on this site' : 'Pause on this site');
  site.addEventListener('click', async () => {
    const allow = paused ? settings.allow.filter((h) => h !== host) : [...settings.allow, host];
    await chrome.storage.local.set({ allow });
    setTimeout(load, 800);
  });
  controls.append(seg, site);
  app.append(controls);

  if (!paused) {
    const row = el('div', 'controls');
    if (removableHidden.length) {
      const rm = el('button', 'primary', 'Remove ' + removableHidden.length + ' hidden item' + (removableHidden.length === 1 ? '' : 's') + ' now');
      rm.addEventListener('click', async () => {
        for (const [fid] of frames) { try { await chrome.tabs.sendMessage(tabId, { type: 'roe:remove', ids: 'hidden' }, { frameId: Number(fid) }); } catch (e) { /* frame gone */ } }
        rm.textContent = 'Removing\u2026'; setTimeout(load, 900);
      });
      row.append(rm);
    }
    const rs = el('button', 'link', 'Rescan');
    rs.addEventListener('click', async () => {
      for (const [fid] of frames) { try { await chrome.tabs.sendMessage(tabId, { type: 'roe:rescan' }, { frameId: Number(fid) }); } catch (e) { /* frame gone */ } }
      setTimeout(load, 700);
    });
    row.append(rs);
    app.append(row);

    if (surf.id === 'github') {
      const g = el('div', 'gh');
      const t = el('button', 'link', settings.ghRaw ? 'GitHub raw check: on (turn off)' : 'GitHub raw check: off (turn on)');
      t.addEventListener('click', async () => { await chrome.storage.local.set({ ghRaw: !settings.ghRaw }); setTimeout(load, 1500); });
      g.append(t);
      if (top.rawStatus) g.append(el('p', '', top.rawStatus));
      g.append(el('p', '', 'Reads the raw Markdown an agent gets from api.github.com, including HTML comments the page never shows. Only the repo and issue number are sent.'));
      app.append(g);
    }

    // category filters
    const counts = {};
    strong.forEach((f) => { counts[f.cat] = (counts[f.cat] || 0) + 1; });
    const catKeys = Object.keys(counts);
    if (catKeys.length > 1) {
      const bar = el('div', 'filters');
      [['all', 'All ' + strong.length], ...catKeys.map((k) => [k, (CATS[k] || k) + ' ' + counts[k]])].forEach(([k, label]) => {
        const b = el('button', '', label);
        b.setAttribute('aria-pressed', String(filter === k));
        b.addEventListener('click', () => { filter = k; render(settings, data); });
        bar.append(b);
      });
      app.append(bar);
    }

    const shown = strong.filter((f) => filter === 'all' || f.cat === filter);
    const list = el('ul');
    shown.forEach((f) => list.append(card(f)));
    app.append(list);

    if (weak.length) {
      const d = el('details');
      d.append(el('summary', '', 'Weak signals (' + weak.length + ')'));
      const wl = el('ul');
      weak.forEach((f) => wl.append(card(f)));
      d.append(wl);
      app.append(d);
    }

    if (sinkList.length) {
      const d = el('details');
      d.append(el('summary', '', 'Sensitive actions available on this page (' + sinkList.length + ')'));
      const sl = el('ul');
      sinkList.forEach((s) => sl.append(el('li', '', s.label + (s.detail ? ' (' + s.detail + ')' : ''))));
      d.append(sl);
      app.append(d);
    }
  }

  // files, images and downloads
  const files = el('details');
  const dls = settings.downloadScans || [];
  const flaggedDl = dls.filter((d) => d.findings.some((f) => f.level !== 'low')).length;
  files.append(el('summary', '', 'Files, images and downloads' + (flaggedDl ? ' (' + flaggedDl + ' flagged)' : '')));
  if (flaggedDl) files.open = true;
  const fbox = el('div', 'gh');
  const open = el('button', 'primary', 'Scan a file or image\u2026');
  open.addEventListener('click', () => chrome.tabs.create({ url: chrome.runtime.getURL('scan.html') }));
  fbox.append(open);
  const toggle = (key, on, off) => {
    const t = el('button', 'link', settings[key] ? on : off);
    t.addEventListener('click', async () => { await chrome.storage.local.set({ [key]: !settings[key] }); setTimeout(load, 600); });
    const p = el('p'); p.append(t); return p;
  };
  fbox.append(
    toggle('scanImages', 'Scan images on pages: on (turn off)', 'Scan images on pages: off (turn on)'),
    el('p', '', 'Each displayed image is fetched again without cookies, from the browser cache when it can, and checked for hidden text in its metadata and near-invisible text.'),
    toggle('scanDownloads', 'Scan downloads: on (turn off)', 'Scan downloads: off (turn on)'),
    el('p', '', 'Needs \u201CAllow access to file URLs\u201D for Roe in chrome://extensions. Files stay on this device.')
  );
  if (dls.some((d) => d.error === 'file-access')) fbox.append(el('p', 'notes', 'The last download could not be read. Turn on \u201CAllow access to file URLs\u201D for Roe in chrome://extensions.'));
  if (dls.length) {
    fbox.append(el('p', '', 'Recent downloads'));
    const ul = el('ul');
    dls.slice(0, 5).forEach((d) => {
      const n = d.findings.filter((f) => f.level !== 'low').length;
      const li = el('li');
      const a = el('button', 'link', d.name + (d.error ? ' (not scanned)' : n ? ' (' + n + ' flagged)' : ' (clean)'));
      a.addEventListener('click', () => chrome.tabs.create({ url: chrome.runtime.getURL('scan.html#dl=' + d.id) }));
      li.append(a); ul.append(li);
    });
    fbox.append(ul);
  }
  files.append(fbox);
  app.append(files);

  // sources behind the rules
  const src = el('details');
  src.append(el('summary', '', 'Sources behind these rules'));
  const sl = el('ul', 'sources');
  Object.values(REFS).forEach((r) => {
    const li = el('li');
    li.append(link(r));
    if (r.anthropic) li.append(el('span', 'tag anth', 'Anthropic'));
    li.append(el('div', 'none', r.note));
    sl.append(li);
  });
  src.append(sl);
  app.append(src);

  app.append(el('p', 'foot', 'Roe reads page content. It cannot see what your AI agent reads, does or sends, so a path shown here is possible, not proven. Removal changes only the page DOM; screenshot-based agents are unaffected.'));
}

function card(f) {
  const li = el('li', 'card ' + f.level);

  const top = el('div', 'top');
  top.append(el('span', 'level', LEVEL[f.level]),
    el('span', 'how', (f.hidden ? 'Hidden: ' : 'Visible: ') + f.technique));
  li.append(top);

  const tags = el('div', 'tags');
  tags.append(el('span', 'tag cat', CATS[f.cat] || f.cat));
  if (f.anthropic) tags.append(el('span', 'tag anth', 'Anthropic-discussed'));
  if (f.kind === 'remote') tags.append(el('span', 'tag', 'Raw, not on page'));
  li.append(tags);

  const split = el('dl', 'split');
  const a = el('div', 'yousee');
  a.append(el('dt', '', 'You see'),
    el('dd', '', f.sanitized || f.gone ? 'Nothing now. Roe removed this from the page.' : f.kind === 'remote' ? 'Nothing. It is in the raw Markdown, not the rendered page.' : f.kind === 'title' ? 'The tab title. It is easy to overlook, and an agent reads it as trusted.' : f.technique === 'file name in link' ? 'Nothing. It is in a link\u2019s file name, which you rarely read.' : f.kind === 'image' ? (/near-invisible/.test(f.technique) ? 'Almost nothing. The text is only a few shades from the background.' : 'Nothing in the picture. It is stored inside the image file.') : f.hidden ? 'Nothing. Your browser does not display it.' : 'This text, in plain view.'));
  const b = el('div', 'agent');
  b.append(el('dt', '', 'An agent reads'), el('dd', '', '\u201C' + f.snippet + '\u201D'));
  split.append(a, b);
  li.append(split);

  li.append(el('p', 'why', f.rules.map((r) => r.label).join('. ') + '.'));

  const refs = (f.refs || []).map((k) => REFS[k]).filter(Boolean);
  if (refs.length) {
    const p = el('p', 'seen', 'Seen in: ');
    refs.forEach((r, i) => { if (i) p.append(document.createTextNode(' \u00B7 ')); p.append(link(r)); });
    li.append(p);
  }

  if (f.sinks && f.sinks.length) {
    const t = el('div', 'targets');
    t.append(el('p', '', 'Could be aimed at'));
    const ul = el('ul');
    f.sinks.forEach((s) => {
      const row = el('li');
      row.append(el('span', s.present ? 'here' : 'none', s.label));
      row.append(el('span', 'tag', s.present ? 'on this page' : 'agent tools only'));
      if (s.present && s.examples.length) row.append(el('div', 'none', s.examples.join(', ')));
      ul.append(row);
    });
    t.append(ul);
    li.append(t);
  }

  const actions = el('div', 'actions');
  if (!f.gone && !f.sanitized && ['text', 'text-group', 'attribute', 'template', 'comment', 'image'].includes(f.kind)) {
    const hiddenText = f.hidden && (f.kind === 'text' || f.kind === 'text-group');
    const orig = hiddenText ? 'Reveal and highlight' : 'Highlight on page';
    const hb = el('button', '', orig);
    let on = false;
    hb.addEventListener('click', async () => {
      try {
        if (on) { await chrome.tabs.sendMessage(tabId, { type: 'roe:unhighlight' }, { frameId: f.frameId }); on = false; hb.textContent = orig; return; }
        const res = await chrome.tabs.sendMessage(tabId, { type: 'roe:highlight', id: f.id }, { frameId: f.frameId });
        if (res && res.ok) { on = true; hb.textContent = 'Clear highlight'; } else hb.textContent = (res && res.reason) || 'Could not highlight';
      } catch (e) { hb.textContent = 'Could not reach the page. Reload it.'; }
    });
    actions.append(hb);
  } else if (f.kind === 'title' && !f.gone && !f.sanitized) {
    actions.append(el('span', 'how', 'Shown on the browser tab'));
  }
  if (f.removable && !f.sanitized && !f.gone) {
    const rm = el('button', 'danger', f.kind === 'image' ? 'Remove image from page' : f.kind === 'title' ? 'Replace tab title' : 'Remove from page');
    rm.addEventListener('click', async () => {
      try {
        const res = await chrome.tabs.sendMessage(tabId, { type: 'roe:remove', ids: [f.id] }, { frameId: f.frameId });
        rm.textContent = res && res.removed ? 'Removed' : 'Could not remove';
        setTimeout(load, 700);
      } catch (e) { rm.textContent = 'Could not remove'; }
    });
    actions.append(rm);
  }
  const c = el('button', '', 'Copy evidence');
  c.addEventListener('click', async () => {
    const ev = { url: f.frame || null, kind: f.kind, category: f.cat, technique: f.technique, hidden: f.hidden, level: f.level, score: f.score, rules: f.rules.map((r) => r.id), sources: f.refs, element: f.where, text: f.snippet };
    await navigator.clipboard.writeText(JSON.stringify(ev, null, 2));
    c.textContent = 'Copied';
  });
  actions.append(c);
  li.append(actions);
  return li;
}

load();
