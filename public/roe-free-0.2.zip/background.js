// Roe service worker: collects each frame's report per tab, drives the toolbar badge,
// and (opt-in) fetches the raw Markdown an agent would read through the GitHub API.
const tabKey = (id) => 'tab:' + id;
let queue = Promise.resolve();
const enqueue = (fn) => (queue = queue.then(fn, fn));

function updateBadge(tabId, data) {
  let medium = 0, high = 0;
  for (const rep of Object.values(data.frames)) {
    for (const f of rep.findings) {
      if (f.gone) continue;
      if (f.level === 'high') high++;
      else if (f.level === 'medium') medium++;
    }
  }
  const n = high + medium;
  chrome.action.setBadgeText({ tabId, text: n ? String(n) : '' });
  chrome.action.setBadgeBackgroundColor({ tabId, color: high ? '#B00B3A' : '#9A5B00' });
}

// ---------- GitHub raw Markdown ----------
const GH_CACHE = new Map(); // key -> { at, items }
const NAME = /^[A-Za-z0-9_.-]{1,100}$/;
const trim = (s) => (typeof s === 'string' ? s.slice(0, 20000) : '');

async function githubRaw(t) {
  if (!t || !NAME.test(t.owner) || !NAME.test(t.repo) || (t.number && !/^\d{1,9}$/.test(t.number))) return { items: [], error: 'bad target' };
  const key = [t.owner, t.repo, t.kind, t.number || ''].join('/');
  const hit = GH_CACHE.get(key);
  if (hit && Date.now() - hit.at < 5 * 60 * 1000) return { items: hit.items };
  const base = 'https://api.github.com/repos/' + t.owner + '/' + t.repo;
  const opt = { headers: { Accept: 'application/vnd.github+json' }, credentials: 'omit' };
  const items = [];
  try {
    if (t.kind === 'repo') {
      const r = await fetch(base + '/readme', { headers: { Accept: 'application/vnd.github.raw+json' }, credentials: 'omit' });
      if (!r.ok) return { items, error: 'GitHub returned ' + r.status + ' (private repo or rate limit)' };
      items.push({ label: 'README', text: trim(await r.text()) });
    } else {
      const r = await fetch(base + '/issues/' + t.number, opt);
      if (!r.ok) return { items, error: 'GitHub returned ' + r.status + ' (private repo or rate limit)' };
      const j = await r.json();
      items.push({ label: (t.kind === 'pull' ? 'Pull request' : 'Issue') + ' description', text: trim(j.body) });
      const c = await fetch(base + '/issues/' + t.number + '/comments?per_page=50', opt);
      if (c.ok) (await c.json()).forEach((x, i) => items.push({ label: 'Comment ' + (i + 1) + ' by ' + (x.user && x.user.login), text: trim(x.body) }));
    }
  } catch (e) { return { items, error: 'network error' }; }
  GH_CACHE.set(key, { at: Date.now(), items });
  return { items };
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg) return false;
  if (msg.type === 'roe:report' && sender.tab) {
    const { id: tabId } = sender.tab;
    const frameId = sender.frameId;
    enqueue(async () => {
      const key = tabKey(tabId);
      const data = (await chrome.storage.session.get(key))[key] || { frames: {} };
      data.frames[frameId] = msg.report;
      await chrome.storage.session.set({ [key]: data });
      updateBadge(tabId, data);
    });
    return false;
  }
  if (msg.type === 'roe:get') {
    enqueue(async () => {
      const key = tabKey(msg.tabId);
      sendResponse((await chrome.storage.session.get(key))[key] || { frames: {} });
    });
    return true; // answer asynchronously
  }
  if (msg.type === 'roe:image' && sender.tab) {
    scanImageUrl(msg.url).then(sendResponse);
    return true;
  }
  if (msg.type === 'roe:github' && sender.tab) {
    githubRaw(msg.target).then(sendResponse);
    return true;
  }
  return false;
});

// A new page load starts a fresh report.
chrome.tabs.onUpdated.addListener((tabId, info) => {
  if (info.status === 'loading') enqueue(() => chrome.storage.session.remove(tabKey(tabId)));
});
chrome.tabs.onRemoved.addListener((tabId) => enqueue(() => chrome.storage.session.remove(tabKey(tabId))));

// ---------- offscreen scanner (documents and images need a DOM) ----------
let offPromise = null;
function ensureOffscreen() {
  if (offPromise) return offPromise;
  offPromise = (async () => {
    const ctxs = await chrome.runtime.getContexts({ contextTypes: ['OFFSCREEN_DOCUMENT'] });
    if (!ctxs.length) await chrome.offscreen.createDocument({ url: 'offscreen.html', reasons: ['DOM_PARSER', 'BLOBS'], justification: 'Parse documents and decode images to look for hidden instructions aimed at AI agents.' });
  })().catch((e) => { offPromise = null; throw e; });
  return offPromise;
}
async function offScan(url, name, max) {
  await ensureOffscreen();
  try { return await chrome.runtime.sendMessage({ type: 'roe:off-scan', url, name, max }); }
  catch (e) { offPromise = null; await ensureOffscreen(); return chrome.runtime.sendMessage({ type: 'roe:off-scan', url, name, max }); }
}

// ---------- images on pages ----------
const IMG_CACHE = new Map();
const EXT = { 'image/png': 'png', 'image/jpeg': 'jpg', 'image/gif': 'gif', 'image/webp': 'webp', 'image/svg+xml': 'svg' };
function imageName(url) {
  if (url.startsWith('data:')) return 'image.' + (EXT[(/^data:([^;,]+)/.exec(url) || [])[1]] || 'png');
  try { const n = new URL(url).pathname.split('/').pop() || 'image'; return /\.(png|jpe?g|gif|webp|svg)$/i.test(n) ? n : n + '.img'; } catch (e) { return 'image.img'; }
}
async function scanImageUrl(url) {
  if (!/^(https?:|data:image\/)/.test(url)) return { ok: false, error: 'unsupported' };
  if (IMG_CACHE.has(url)) return IMG_CACHE.get(url);
  const res = await offScan(url, imageName(url), 8 * 1024 * 1024).catch((e) => ({ ok: false, error: String(e) }));
  if (IMG_CACHE.size > 200) IMG_CACHE.delete(IMG_CACHE.keys().next().value);
  IMG_CACHE.set(url, res);
  return res;
}

// ---------- downloads ----------
const SKIP_DL = /\.(mp[34]|m4a|mov|avi|mkv|webm|iso|dmg|exe|msi|apk|deb|rpm|torrent|woff2?|ttf|otf)$/i;
const fileUrl = (p) => (p.startsWith('/') ? 'file://' + encodeURI(p) : 'file:///' + encodeURI(p.replace(/\\/g, '/')));
async function scanDownload(item) {
  const name = item.filename.split(/[\\/]/).pop();
  const rec = { id: item.id, name, at: Date.now(), kind: '', findings: [], notes: [], error: '' };
  try {
    const r = await offScan(fileUrl(item.filename), name, 40 * 1024 * 1024);
    if (!r || !r.ok) rec.error = /Failed to fetch|NetworkError/i.test((r && r.error) || '') ? 'file-access' : ((r && r.error) || 'unreadable');
    else { rec.kind = r.res.kind; rec.notes = r.res.notes.slice(0, 6); rec.findings = r.res.findings.slice(0, 25); }
  } catch (e) { rec.error = 'unreadable'; }
  const { downloadScans = [] } = await chrome.storage.local.get('downloadScans');
  await chrome.storage.local.set({ downloadScans: [rec, ...downloadScans.filter((x) => x.id !== rec.id)].slice(0, 25) });
  const strong = rec.findings.filter((f) => f.level !== 'low').length;
  if (strong) {
    chrome.notifications.create('roe-dl-' + rec.id, { type: 'basic', iconUrl: 'icons/128.png', title: 'Roe: instructions aimed at AI agents in a download',
      message: name + ': ' + strong + (strong === 1 ? ' possible attack' : ' possible attacks') + '. Click to see what an agent would read.' });
  }
  return rec;
}
async function onDownloadChanged(delta) {
  if (!delta.state || delta.state.current !== 'complete') return;
  const s = await chrome.storage.local.get({ scanDownloads: true });
  if (!s.scanDownloads) return;
  const [item] = await chrome.downloads.search({ id: delta.id });
  if (!item || !item.filename || SKIP_DL.test(item.filename) || item.fileSize > 40 * 1024 * 1024) return;
  let rec = await scanDownload(item);
  if (rec.error && rec.error !== 'file-access') { await new Promise((r) => setTimeout(r, 1500)); rec = await scanDownload(item); }   // one retry for transient failures
}
chrome.downloads.onChanged.addListener((delta) => { onDownloadChanged(delta).catch((e) => console.warn('Roe: download scan failed', e)); });
chrome.notifications.onClicked.addListener((id) => {
  const m = /^roe-dl-(\d+)$/.exec(id);
  if (m) { chrome.tabs.create({ url: chrome.runtime.getURL('scan.html#dl=' + m[1]) }); chrome.notifications.clear(id); }
});
