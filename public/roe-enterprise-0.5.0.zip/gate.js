// Roe action gate (enterprise tier). Classifies sensitive actions, attributes them to a person or an agent,
// evaluates org policy, and allows, blocks, or asks a human in an extension window.
// On the free tier this file does nothing: no listeners are attached and the page is never touched.
(() => {
  if (!self.Roe || window.__roeGate) return;
  window.__roeGate = true;
  const R = Roe;
  const host = location.hostname;

  const send = (m) => new Promise((res) => {
    try { chrome.runtime.sendMessage(m, (r) => { void chrome.runtime.lastError; res(r); }); } catch (e) { res(null); }
  });

  let policy = R.normalizePolicy({});
  let enterprise = false, started = false;
  let tabId = null, marked = false, taint = null, clip = null, intent = null, quarantine = null, payloads = [];
  let inserting = false, lastBlockAt = 0, retries = 0, lastToast = 0;
  const bypass = new WeakSet();

  // ---------- state ----------
  async function loadPolicy() {
    const r = await send({ type: 'roe:policy' });
    if (!r || !r.policy) return;
    policy = R.normalizePolicy(r.policy);
    enterprise = r.tier === 'enterprise';
    if (enterprise) { start(); ensureTripwire(); }
  }
  async function loadSession() {
    try {
      const s = await chrome.storage.session.get(['taint', 'agentTabs', 'clip', 'intent', 'quarantine', 'payloads']);
      const had = !!quarantine;
      taint = s.taint || null; clip = s.clip || null; intent = s.intent || null; quarantine = s.quarantine || null; payloads = s.payloads || [];
      if (had && !quarantine) { retries = 0; lastBlockAt = 0; } // released by a human: start counting again
      marked = !!(s.agentTabs && tabId !== null && s.agentTabs[tabId]);
    } catch (e) { /* session storage not reachable */ }
  }
  (async () => {
    const w = await send({ type: 'roe:whoami' });
    tabId = w ? w.tabId : null;
    await loadSession();
    await loadPolicy();
  })();
  try {
    chrome.storage.onChanged.addListener((ch, area) => {
      if (area === 'session') loadSession();
      else if (area === 'managed' || (area === 'local' && (ch.devPolicy || ch.tier))) loadPolicy();
    });
  } catch (e) { /* ignore */ }

  const localTaint = () => !!(R.localFindings && R.localFindings.high + R.localFindings.medium > 0);
  const globalTaint = () => !!(taint && Date.now() - taint.at < (policy.taintTtlMinutes || 15) * 60000);
  const isTainted = () => localTaint() || globalTaint();
  const taintSource = () => (localTaint() ? location.host + ' (this page)' : globalTaint() ? taint.source : null);
  const intentActive = () => !!(intent && Date.now() - intent.at < (policy.intent.ttlMinutes || 30) * 60000);
  const quarantined = () => !!quarantine;

  // ---------- helpers ----------
  const labelOf = (el) => ((el.tagName === 'INPUT' && el.value) || el.getAttribute('aria-label') || el.textContent || el.title || '').trim().replace(/\s+/g, ' ').slice(0, 60);
  const OAUTH_PAGE = /[?&]client_id=|\/oauth2?\/(v\d+(\.\d+)?\/)?authori[sz]e|\/o\/oauth2\/|\/consent\b/i;
  const CLASSES = [
    ['install', /\b(add to (chrome|edge|brave)|install extension|add extension)\b/i],
    ['payment', /\b(pay|payment|purchase|buy now|checkout|place order|transfer|wire|send money|withdraw|payout)\b/i],
    ['delete', /\b(delete|remove|revoke|disable|deactivate|terminate|erase|wipe)\b/i],
    ['permission', /\b(allow|authori[sz]e|grant|approve|invite|share|make admin|give access)\b/i],
    ['send', /\b(send|forward|reply|post|publish|email)\b/i],
    ['download', /\bdownload\b/i]
  ];
  function classify(el) {
    if (el.matches('input[type=file]')) return ['upload', labelOf(el) || 'Upload file'];
    const label = labelOf(el);
    if (OAUTH_PAGE.test(location.href) && /\b(allow|authori[sz]e|accept|grant|approve|continue|yes)\b/i.test(label)) return ['oauth-consent', label];
    for (const [a, re] of CLASSES) if (re.test(label)) return [a, label];
    if (el.tagName === 'A' && el.href && /^https?:/.test(el.href)) {
      try { if (new URL(el.href, location.href).origin !== location.origin) return ['navigate-external', label || el.href]; } catch (e) { /* ignore */ }
    }
    return null;
  }

  function actorOf(e, el, kind) {
    const sig = R.attribution.signals(e, el, kind);
    sig.markedByUser = marked;
    sig.treatAll = policy.treatAllAsAgent;
    const s = R.scoreActor(sig);
    return { actor: s.confidence >= policy.agentThreshold ? 'agent' : 'human', confidence: s.confidence, signals: s.signals };
  }

  function toast(msg) {
    if (Date.now() - lastToast < 2500) return;
    lastToast = Date.now();
    try {
      const h = document.createElement('div');
      const root = h.attachShadow({ mode: 'closed' });
      const s = document.createElement('style');
      s.textContent = '.t{position:fixed;right:16px;bottom:16px;max-width:320px;z-index:2147483647;background:#12212E;color:#fff;font:13px/1.4 system-ui,sans-serif;padding:10px 12px;border-left:4px solid #B00B3A;border-radius:4px}';
      const d = document.createElement('div');
      d.className = 't'; d.textContent = msg;
      root.append(s, d);
      document.documentElement.append(h);
      setTimeout(() => h.remove(), 5000);
    } catch (e) { /* ignore */ }
  }

  function insert(target, text) {
    inserting = true;
    try {
      if (target && target.focus) target.focus();
      const ok = document.execCommand && document.execCommand('insertText', false, text);
      if (!ok && target && 'value' in target) target.value += text;
    } finally { inserting = false; }
  }

  // ---------- quarantine: stop every agent action until a human releases the session ----------
  function startQuarantine(reason, detail) {
    if (quarantine) return;
    quarantine = { at: Date.now(), reason, detail: detail || '', host };
    send({ type: 'roe:quarantine', reason, detail: detail || '', host });
    toast('Roe quarantined this agent session (' + reason.replace(/-/g, ' ') + '). Release it from the Roe popup.');
  }
  // An agent that retries after being stopped, by another route, is probing the policy.
  function noteAttempt(who) {
    if (who.actor !== 'agent') return;
    const win = (policy.quarantine.retryWindowSeconds || 90) * 1000, now = Date.now();
    if (!lastBlockAt || now - lastBlockAt > win) { retries = 0; return; }
    retries++;
    if (retries >= (policy.quarantine.retryThreshold || 2)) startQuarantine('retry-after-block', retries + ' attempts after an action was stopped');
  }

  // ---------- worm signals: is the agent writing instructions for other agents, or repeating ones it read? ----------
  const HOT = ['injection', 'replicate', 'directive', 'trace', 'persist', 'exfil', 'tool', 'email'];
  function wormSignals(text) {
    const out = { flags: [], worm: false, replication: false, fp: null };
    if (!text || text.length < 12) return out;
    const a = R.analyze(text);
    if (a && ((a.cats.includes('replicate') && a.score >= 20) || (a.cats.some((c) => HOT.includes(c)) && a.score >= 30))) {
      out.worm = true;
      out.flags.push({ type: 'outbound-injection', label: 'Text addressed to AI agents (' + (R.CATS[a.cat] || a.cat) + ')' });
    }
    const sh = R.shingles(text, 3);
    const fresh = payloads.filter((p) => Date.now() - p.at < 2 * 3600 * 1000);
    for (const p of fresh) {
      if (!p.shingles || p.shingles.length < (policy.worm.minShingles || 6)) continue;
      const c = R.containment(p.shingles, sh);
      if (c >= (policy.worm.containment || 0.35)) {
        out.replication = true;
        out.flags.push({ type: 'payload-replication', label: 'Repeats instructions read earlier on ' + p.source + ' (' + Math.round(c * 100) + '% match)' });
        break;
      }
    }
    if (text.length >= 40) out.fp = R.hash53(R.normText(text).slice(0, 300));
    return out;
  }
  // Text sitting in compose boxes and editors, for agents that type key by key.
  function outboundText() {
    const parts = [];
    for (const n of document.querySelectorAll('textarea,[contenteditable=""],[contenteditable="true"],input[type=text],input:not([type])')) {
      const v = typeof n.value === 'string' ? n.value : n.textContent;
      if (v && v.length >= 8) parts.push(v.slice(0, 2000));
      if (parts.length >= 6) break;
    }
    return parts.join('\n');
  }

  // ---------- the gate ----------
  const NEEDS_TASK = ['submit', 'send', 'payment', 'delete', 'permission', 'upload', 'oauth-consent', 'install'];
  const CARRIER_ACTIONS = ['submit', 'send', 'type', 'paste', 'upload'];

  function buildCtx(action, who, dlp, extra) {
    const ctx = { host, actor: who.actor, action, tainted: isTainted(), dlp, deviation: false, noTask: false, carrier: false, quarantined: quarantined(), worm: !!extra.worm, replication: !!extra.replication };
    if (who.actor === 'agent') {
      if (intentActive()) {
        const why = R.intentDeviation(intent, action, host);
        if (why) { ctx.deviation = true; ctx.deviationWhy = why; }
      } else if (policy.intent.requireIntent && NEEDS_TASK.includes(action)) ctx.noTask = true;
    }
    if (CARRIER_ACTIONS.includes(action)) {
      const c = R.carrierMatch(policy, location.href);
      if (c) { ctx.carrier = true; ctx.carrierLabel = c.label; }
    }
    return ctx;
  }

  function record(d, who, action, label, outcome, dlp, extra, note) {
    if (who.actor !== 'agent' && d.would === 'allow') return; // don't log ordinary human activity
    const c = d.ctx;
    send({
      type: 'roe:audit',
      event: {
        kind: 'action', host, page: location.pathname.slice(0, 80), actor: who.actor, confidence: who.confidence, signals: who.signals,
        action, label: label.slice(0, 60), decision: d.would, outcome, rule: d.rule, tainted: c.tainted, taintSource: taintSource(),
        taintAge: taint && c.tainted ? Math.round((Date.now() - taint.at) / 1000) : undefined,
        dlp: dlp.map((x) => x.type), flags: (extra.flags || []).map((x) => x.type), fp: extra.fp || undefined,
        deviation: c.deviationWhy, carrier: c.carrierLabel, mode: policy.mode, note: note || ''
      }
    });
  }

  // preventDefault runs synchronously (before the first await) so the page never sees a blocked action.
  async function gate(e, action, label, who, dlp, resume, extra) {
    extra = extra || {};
    noteAttempt(who);
    const ctx = buildCtx(action, who, dlp, extra);
    const d = R.evaluate(policy, ctx);
    d.ctx = ctx;
    if (d.effect === 'allow') { record(d, who, action, label, d.would === 'allow' ? 'allowed' : 'monitored', dlp, extra); return; }
    e.preventDefault();
    e.stopImmediatePropagation();
    if (d.effect === 'block') {
      lastBlockAt = Date.now();
      record(d, who, action, label, 'blocked', dlp, extra);
      toast('Roe blocked an agent action: ' + label + '. ' + (d.reasons[0] || ''));
      return;
    }
    const res = await send({
      type: 'roe:approve',
      request: {
        host, action, label, actor: who.actor, confidence: who.confidence, signals: who.signals, rule: d.rule, reasons: d.reasons,
        tainted: ctx.tainted, taintSource: taintSource(), dlp: dlp.map((x) => x.label), flags: (extra.flags || []).map((x) => x.label),
        deviation: ctx.deviationWhy || '', carrier: ctx.carrierLabel || ''
      }
    });
    const ok = !!(res && res.approved);
    if (!ok) lastBlockAt = Date.now();
    record(d, who, action, label, ok ? 'approved' : 'denied', dlp, extra, res && res.note);
    if (ok) resume();
  }

  function tripwireHit(e) {
    e.preventDefault();
    e.stopImmediatePropagation();
    const who = actorOf(e, e.target, 'click');
    send({ type: 'roe:audit', event: { kind: 'tripwire', host, page: location.pathname.slice(0, 80), actor: 'agent', confidence: Math.max(who.confidence, 0.9), signals: ['clicked an off-screen element no person can see or reach'], action: 'tripwire', label: 'Off-screen lure', outcome: 'tripwire', tainted: isTainted(), taintSource: taintSource(), mode: policy.mode } });
    startQuarantine('tripwire', 'The agent clicked an element only a DOM-reading agent can see');
  }
  function ensureTripwire() {
    if (window.top !== window || !policy.tripwires || !document.body || document.querySelector('[data-roe-tw]')) return;
    const b = document.createElement('button');
    b.type = 'button'; b.tabIndex = -1;
    b.setAttribute('data-roe-tw', '1');
    b.setAttribute('aria-label', 'Export all customer records');
    b.textContent = 'Export all customer records';
    b.style.cssText = 'position:absolute!important;left:-10000px!important;top:0!important;width:1px!important;height:1px!important;overflow:hidden!important';
    document.body.append(b);
  }

  function onClick(e) {
    if (!enterprise) return;
    if (e.target instanceof Element && e.target.closest('[data-roe-tw]')) { tripwireHit(e); return; }
    const el = e.target instanceof Element ? e.target.closest('button,a[href],input[type=submit],input[type=button],input[type=file],[role=button]') : null;
    if (!el) return;
    if (bypass.has(el)) { bypass.delete(el); return; }
    if ((el.tagName === 'BUTTON' || el.tagName === 'INPUT') && el.form && (el.type === 'submit' || el.type === 'image')) return; // handled by the submit event
    let c = classify(el);
    if (!c && quarantined()) c = ['click', labelOf(el) || 'Click'];
    if (!c) return;
    const extra = c[0] === 'send' ? wormSignals(outboundText()) : {};
    gate(e, c[0], c[1], actorOf(e, el, 'click'), [], () => { bypass.add(el); el.click(); }, extra);
  }

  function onSubmit(e) {
    if (!enterprise) return;
    const form = e.target;
    if (!(form instanceof HTMLFormElement)) return;
    if (bypass.has(form)) { bypass.delete(form); return; }
    const sub = e.submitter || null;
    let label = (sub && labelOf(sub)) || form.getAttribute('aria-label') || 'Submit form';
    let action = 'submit';
    const c = sub && classify(sub);
    if (c && c[0] !== 'navigate-external') action = c[0];
    if (form.querySelector('input[autocomplete^="cc-"],input[name*="card" i],input[name*="iban" i]')) action = 'payment';
    let target;
    try { target = new URL(form.getAttribute('action') || location.href, location.href); } catch (err) { target = location; }
    if (target.origin !== location.origin) label += ' to ' + target.host;
    const text = [...form.elements].filter((f) => f.type !== 'password' && f.type !== 'hidden' && typeof f.value === 'string' && f.value.length >= 8).map((f) => f.value).join('\n');
    const dlp = R.dlpScan(text, policy.dlp.detectors);
    const extra = wormSignals(text + '\n' + outboundText());
    gate(e, action, label, actorOf(e, sub || form, 'submit'), dlp, () => {
      bypass.add(form);
      try { form.requestSubmit(sub || undefined); } catch (err) { form.submit(); }
    }, extra);
  }

  function textGate(e, action, text, label) {
    const dlp = R.dlpScan(text, policy.dlp.detectors);
    if (clip && clip.fromHost !== host && Date.now() - clip.at < 30 * 60000 && clip.h === R.hash53(R.normText(text))) {
      dlp.push({ type: 'copied-from-protected-site', label: 'Copied from ' + clip.fromHost + ' (' + clip.classes.join(', ') + ')' });
    }
    gate(e, action, label, actorOf(e, null, 'text'), dlp, () => insert(e.target, text), wormSignals(text));
  }
  function onPaste(e) {
    if (!enterprise || inserting) return;
    const text = (e.clipboardData && e.clipboardData.getData('text/plain')) || '';
    if (text.length >= 8) textGate(e, 'paste', text, 'Paste ' + text.length + ' characters');
  }
  function onBeforeInput(e) {
    if (!enterprise || inserting || e.inputType !== 'insertText' || !e.data || e.data.length < 8) return;
    textGate(e, 'type', e.data, 'Insert ' + e.data.length + ' characters');
  }

  function selectedText() {
    const a = document.activeElement;
    if (a && (a.tagName === 'TEXTAREA' || a.tagName === 'INPUT') && typeof a.selectionStart === 'number' && a.selectionEnd > a.selectionStart) return a.value.slice(a.selectionStart, a.selectionEnd);
    const s = getSelection();
    return s ? s.toString() : '';
  }
  function onCopy() {
    if (!enterprise) return;
    const classes = R.classesOf(policy, host).filter((c) => policy.dlp.protectedCopyClasses.includes(c));
    if (!classes.length) return;
    const t = selectedText();
    if (t.length < 8) return;
    try { chrome.storage.session.set({ clip: { h: R.hash53(R.normText(t)), len: t.length, fromHost: host, classes, at: Date.now() } }); } catch (e) { /* ignore */ }
  }

  // Listeners are attached only once the org's tier is known to be enterprise.
  function start() {
    if (started) return;
    started = true;
    R.attribution.observe();
    document.addEventListener('click', (e) => R.attribution.recordClick(e), { capture: true, passive: true });
    document.addEventListener('click', onClick, true);
    document.addEventListener('submit', onSubmit, true);
    document.addEventListener('paste', onPaste, true);
    document.addEventListener('beforeinput', onBeforeInput, true);
    document.addEventListener('copy', onCopy, true);
    document.addEventListener('cut', onCopy, true);
  }
})();
