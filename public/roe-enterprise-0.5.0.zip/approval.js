// Approval window. Runs in an extension page, so the web page cannot read, restyle or click it.
const id = new URLSearchParams(location.search).get('id');
const app = document.getElementById('app');
const el = (t, c, x) => { const n = document.createElement(t); if (c) n.className = c; if (x !== undefined) n.textContent = x; return n; };
const NAMES = { 'oauth-consent': 'approve an OAuth consent screen', install: 'install a browser extension', click: 'click something', payment: 'make a payment', send: 'send something', delete: 'delete or remove something', permission: 'change permissions or grant access', submit: 'submit a form', upload: 'upload a file', paste: 'paste text', type: 'enter text', download: 'download a file', 'navigate-external': 'leave this site' };

function row(dl, k, v) { dl.append(el('dt', '', k), el('dd', '', v)); }

(async () => {
  const r = await chrome.runtime.sendMessage({ type: 'roe:approval-get', id });
  if (!r) { app.append(el('h1', 'q', 'This request has expired'), el('p', 'sub', 'You can close this window.')); return; }

  app.append(el('h1', 'q', 'An agent wants to ' + (NAMES[r.action] || r.action)), el('p', 'sub', 'Nothing happens unless you approve it.'));
  const what = el('div', 'what');
  what.append(el('b', '', r.label), el('span', '', 'on ' + r.host));
  app.append(what);

  const dl = el('dl');
  row(dl, 'Why Roe is asking', (r.reasons && r.reasons[0]) || 'Policy requires confirmation');
  row(dl, 'Why this looks like an agent', Math.round(r.confidence * 100) + '% confidence. ' + (r.signals.length ? r.signals.join('; ') + '.' : ''));
  if (r.tainted) {
    const d = el('dd', 'warn', 'This browser session was exposed to hidden instructions' + (r.taintSource ? ' (' + r.taintSource + ')' : '') + '. The agent may be following them.');
    dl.append(el('dt', '', 'Warning'), d);
  }
  if (r.dlp && r.dlp.length) {
    const dd = el('dd'); const ul = el('ul'); r.dlp.forEach((x) => ul.append(el('li', '', x))); dd.append(ul);
    dl.append(el('dt', '', 'Sensitive data detected'), dd);
  }
  if (r.deviation) dl.append(el('dt', '', 'Outside the task'), el('dd', 'warn', r.deviation + '.'));
  if (r.carrier) dl.append(el('dt', '', 'Where this would be written'), el('dd', 'warn', r.carrier + '. Text written here can steer future agents.'));
  if (r.flags && r.flags.length) {
    const dd = el('dd', 'warn'); const ul = el('ul'); r.flags.forEach((x) => ul.append(el('li', '', x))); dd.append(ul);
    dl.append(el('dt', '', 'Worm-like behavior'), dd);
  }
  app.append(dl);

  const note = el('textarea'); note.placeholder = 'Optional note for the audit log'; note.maxLength = 200;
  app.append(note);

  const deny = el('button', '', 'Deny'); deny.id = 'deny';
  const ok = el('button', '', 'Approve once'); ok.id = 'ok'; ok.disabled = true;
  const row_ = el('div', 'row'); row_.append(deny, ok); app.append(row_);
  app.append(el('p', 'fine', 'Approve only if you started this task and expect this action. If an agent is driving this browser, it may be able to click this window too; high-risk approvals should use a second factor.'));

  const done = (approved) => chrome.runtime.sendMessage({ type: 'roe:approval-resolve', id, approved, note: note.value }).then(() => window.close());
  deny.addEventListener('click', () => done(false));
  ok.addEventListener('click', (e) => { if (e.isTrusted) done(true); });
  setTimeout(() => { ok.disabled = false; }, 1500); // dwell time so it cannot be approved by reflex
  deny.focus();
})();
