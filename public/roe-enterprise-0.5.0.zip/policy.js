// Roe policy engine (enterprise). Pure functions, shared by the content script, service worker, popup and console.
(function () {
  const Roe = (self.Roe = self.Roe || {});

  Roe.DEFAULT_POLICY = {
    version: 2,
    org: '',
    mode: 'enforce',            // 'monitor' logs what would happen but never blocks
    agentThreshold: 0.5,        // attribution confidence at which an actor counts as an agent
    treatAllAsAgent: false,     // testing aid: score every actor as an agent
    taintTtlMinutes: 15,        // how long exposure to hidden instructions keeps tightening policy
    tripwires: false,           // plant an off-screen lure that only a DOM-reading agent would click
    siteClasses: {
      banking: ['*.chase.com', '*.bankofamerica.com', '*.paypal.com', 'banking.*', 'netbanking.*'],
      hr: ['*.workday.com', '*.adp.com', '*.bamboohr.com'],
      admin: ['admin.*', '*.admin.*', 'console.*'],
      internal: ['*.corp.example.com', 'localhost']
    },
    agentAllowedDomains: [],    // if non-empty, agents may only act on these hosts (reading is unaffected)
    dlp: {
      detectors: ['aws-key', 'private-key', 'github-token', 'slack-token', 'jwt', 'secret-assignment', 'card', 'ssn'],
      protectedCopyClasses: ['internal', 'banking', 'hr', 'admin']
    },
    intent: { ttlMinutes: 30, requireIntent: false },
    quarantine: { retryThreshold: 2, retryWindowSeconds: 90, onWormFanOut: true },
    anomaly: { maxActionsPer60s: 8, maxHostsPerSession: 6, fanOutThreshold: 3 },
    worm: { containment: 0.35, minShingles: 6 },
    // Pages where an agent writing text can plant instructions that outlive the session. Editable; check them against your tools.
    carriers: [
      { id: 'agent-instruction-file', label: 'Agent instruction file (AGENTS.md, CLAUDE.md, rules files)', urlRegex: '(AGENTS|CLAUDE|GEMINI|SKILL)\\.md|\\.cursorrules|copilot-instructions\\.md|\\.windsurfrules' },
      { id: 'assistant-memory', label: 'Assistant memory or custom instructions', urlRegex: '(chatgpt\\.com|claude\\.ai|gemini\\.google\\.com).*(settings|memory|personali[sz]ation|custom[-_ ]?instructions|saved-info)' }
    ],
    rules: [
      { id: 'agents-read-only-banking-hr', description: 'Agents may read but not act on banking and HR sites', actor: 'agent', sites: ['banking', 'hr'], actions: ['*'], effect: 'block' },
      { id: 'agents-no-admin-forms', description: 'Agents may not submit forms or change things on admin panels', actor: 'agent', sites: ['admin'], actions: ['submit', 'payment', 'delete', 'permission'], effect: 'block' },
      { id: 'agents-no-oauth-consent', description: 'Agents may not approve OAuth consent screens', actor: 'agent', actions: ['oauth-consent'], effect: 'block' },
      { id: 'agents-no-extension-install', description: 'Agents may not install browser extensions', actor: 'agent', actions: ['install'], effect: 'block' },
      { id: 'quarantine-lockdown', description: 'This agent session is quarantined until a human releases it', actor: 'agent', quarantined: true, actions: ['*'], effect: 'block' },
      { id: 'worm-replication', description: 'The agent is repeating instructions it read earlier into an outward channel (worm-like)', actor: 'agent', replication: true, actions: ['*'], effect: 'block' },
      { id: 'worm-outbound-tainted', description: 'After exposure to hidden instructions, the agent is writing instructions aimed at other agents', actor: 'agent', worm: true, tainted: true, actions: ['*'], effect: 'block' },
      { id: 'worm-outbound-injection', description: 'The agent is writing text addressed to AI agents into an outward channel', actor: 'agent', worm: true, actions: ['*'], effect: 'confirm' },
      { id: 'carrier-writes', description: 'The agent is writing to a place that can store instructions for future agents', actor: 'agent', carrier: true, actions: ['submit', 'send', 'type', 'paste', 'upload'], effect: 'confirm' },
      { id: 'intent-deviation-tainted', description: 'After exposure to hidden instructions, the agent is acting outside the task you gave it', actor: 'agent', deviation: true, tainted: true, actions: ['*'], effect: 'block' },
      { id: 'intent-deviation', description: 'The agent is acting outside the task you gave it', actor: 'agent', deviation: true, actions: ['*'], effect: 'confirm' },
      { id: 'no-task-declared', description: 'No task was declared for this agent session', actor: 'agent', noTask: true, actions: ['*'], effect: 'confirm' },
      { id: 'confirm-high-impact', description: 'Payments, sends, deletes and permission changes by an agent need human confirmation', actor: 'agent', actions: ['payment', 'send', 'delete', 'permission'], effect: 'confirm' },
      { id: 'tainted-session-actions', description: 'After exposure to hidden instructions, outward actions by an agent need confirmation', actor: 'agent', tainted: true, actions: ['submit', 'send', 'payment', 'delete', 'permission', 'upload', 'paste', 'type', 'navigate-external'], effect: 'confirm' },
      { id: 'agent-dlp', description: 'Agents may not move sensitive data into forms or prompts', actor: 'agent', dlp: true, actions: ['*'], effect: 'block' }
    ]
  };

  Roe.normalizePolicy = function (p) {
    const d = Roe.DEFAULT_POLICY;
    p = p && typeof p === 'object' ? p : {};
    return {
      ...d, ...p,
      siteClasses: { ...d.siteClasses, ...(p.siteClasses || {}) },
      dlp: { ...d.dlp, ...(p.dlp || {}) },
      intent: { ...d.intent, ...(p.intent || {}) },
      quarantine: { ...d.quarantine, ...(p.quarantine || {}) },
      anomaly: { ...d.anomaly, ...(p.anomaly || {}) },
      worm: { ...d.worm, ...(p.worm || {}) },
      carriers: Array.isArray(p.carriers) ? p.carriers : d.carriers,
      agentAllowedDomains: Array.isArray(p.agentAllowedDomains) ? p.agentAllowedDomains : d.agentAllowedDomains,
      rules: Array.isArray(p.rules) ? p.rules : d.rules
    };
  };

  Roe.validatePolicy = function (p) {
    if (!p || typeof p !== 'object' || Array.isArray(p)) return ['Policy must be a JSON object'];
    const errs = [];
    if (p.mode !== undefined && !['enforce', 'monitor'].includes(p.mode)) errs.push('mode must be "enforce" or "monitor"');
    if (p.rules !== undefined && !Array.isArray(p.rules)) errs.push('rules must be an array');
    (Array.isArray(p.rules) ? p.rules : []).forEach((r, i) => {
      if (!r || !r.id) errs.push('rules[' + i + '] needs an id');
      if (!r || !['allow', 'confirm', 'block'].includes(r.effect)) errs.push('rules[' + i + '].effect must be allow, confirm or block');
    });
    if (p.agentThreshold !== undefined && !(p.agentThreshold > 0 && p.agentThreshold <= 1)) errs.push('agentThreshold must be between 0 and 1');
    (Array.isArray(p.carriers) ? p.carriers : []).forEach((c, i) => {
      try { new RegExp(c.urlRegex); } catch (e) { errs.push('carriers[' + i + '].urlRegex is not a valid regular expression'); }
    });
    return errs;
  };

  // ---------- hosts ----------
  const cache = new Map();
  // '*.example.com' also matches 'example.com'; 'bank.*' matches 'bank.anything'.
  Roe.matchHost = function (pattern, host) {
    let r = cache.get(pattern);
    if (!r) {
      const esc = String(pattern).toLowerCase().replace(/[.+?^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '.*');
      r = { re: new RegExp('^' + esc + '$'), bare: String(pattern).startsWith('*.') ? String(pattern).slice(2).toLowerCase() : null };
      cache.set(pattern, r);
    }
    const h = String(host || '').toLowerCase();
    return r.re.test(h) || (r.bare !== null && h === r.bare);
  };
  Roe.classesOf = (policy, host) =>
    Object.keys(policy.siteClasses).filter((name) => (policy.siteClasses[name] || []).some((pat) => Roe.matchHost(pat, host)));

  // ---------- carriers: places where written text can outlive the session ----------
  const reCache = new Map();
  Roe.carrierMatch = function (policy, href) {
    for (const c of policy.carriers || []) {
      let re = reCache.get(c.urlRegex);
      if (re === undefined) { try { re = new RegExp(c.urlRegex, 'i'); } catch (e) { re = null; } reCache.set(c.urlRegex, re); }
      if (re && re.test(href)) return c;
    }
    return null;
  };

  // ---------- intent lock: the task the human gave the agent ----------
  const VERBS = [
    [['send', 'submit'], /\b(send|e-?mail|reply|respond|message|post|publish|forward|tweet|comment)\b/i],
    [['payment', 'submit'], /\b(buy|purchase|pay|order|book|checkout|reserve|subscribe|donate|transfer)\b/i],
    [['submit'], /\b(fill|submit|apply|register|sign ?up|sign in|log ?in|enroll|rsvp)\b/i],
    [['delete'], /\b(delete|remove|cancel|unsubscribe|clear|archive)\b/i],
    [['download'], /\b(download|save|export)\b/i],
    [['upload'], /\b(upload|attach)\b/i],
    [['permission', 'submit'], /\b(invite|share|grant|give access|add (a )?(user|member|collaborator))\b/i]
  ];
  Roe.BASELINE_ACTIONS = ['type', 'paste', 'navigate-external', 'click']; // normal while reading and searching

  // Turns "book a flight on example-air.com" into the actions and sites that task needs.
  Roe.parseIntent = function (text, hostNow) {
    const t = String(text || '').slice(0, 400);
    const actions = new Set();
    for (const [acts, re] of VERBS) if (re.test(t)) acts.forEach((a) => actions.add(a));
    const mentioned = [...new Set((t.toLowerCase().match(/\b(?:[a-z0-9-]+\.)+[a-z]{2,}\b/g) || []))];
    const hosts = mentioned.length ? [...new Set([...mentioned, ...(hostNow ? [String(hostNow).toLowerCase()] : [])])] : null;
    return { text: t, actions: [...actions], hosts, readOnly: actions.size === 0, at: Date.now() };
  };
  // Returns why an action is outside the task, or null if it fits.
  Roe.intentDeviation = function (intent, action, host) {
    if (!intent || Roe.BASELINE_ACTIONS.includes(action)) return null;
    if (!intent.actions.includes(action)) return intent.readOnly ? 'The task was read-only, but the agent is trying to ' + action : 'The agent is trying to ' + action + ', which the task did not ask for';
    const h = String(host || '').toLowerCase();
    if (intent.hosts && !intent.hosts.some((x) => h === x || h.endsWith('.' + x))) return 'The agent is acting on a site the task did not mention';
    return null;
  };

  // ---------- evaluation ----------
  const ORDER = { allow: 0, confirm: 1, block: 2 };
  const FLAGS = ['tainted', 'deviation', 'worm', 'replication', 'carrier', 'quarantined', 'noTask'];

  // ctx: { host, actor, action, dlp: [], tainted, deviation, worm, replication, carrier, quarantined, noTask }.
  // The strictest matching rule wins.
  Roe.evaluate = function (policy, ctx) {
    let best = { effect: 'allow', rule: null, reasons: [] };
    const bump = (effect, rule, reason) => {
      if (ORDER[effect] > ORDER[best.effect]) best = { effect, rule, reasons: [reason] };
      else if (effect !== 'allow' && effect === best.effect) best.reasons.push(reason);
    };
    const classes = Roe.classesOf(policy, ctx.host);
    if (ctx.actor === 'agent' && policy.agentAllowedDomains.length && !policy.agentAllowedDomains.some((d) => Roe.matchHost(d, ctx.host))) {
      bump('block', 'approved-domains', 'Agents may only act on approved domains');
    }
    for (const r of policy.rules) {
      if (r.actor && r.actor !== 'any' && r.actor !== ctx.actor) continue;
      if (r.sites && r.sites.length && !r.sites.some((s) => classes.includes(s) || Roe.matchHost(s, ctx.host))) continue;
      if (r.actions && r.actions.length && !r.actions.includes('*') && !r.actions.includes(ctx.action)) continue;
      if (FLAGS.some((k) => r[k] && !ctx[k])) continue;
      if (r.dlp && !(ctx.dlp && ctx.dlp.length)) continue;
      bump(r.effect, r.id, r.description || r.id);
    }
    const enforced = policy.mode !== 'monitor';
    return { effect: enforced ? best.effect : 'allow', would: best.effect, rule: best.rule, reasons: best.reasons, classes };
  };
})();
