// Roe agent attribution: scores whether an action came from a person or an automated agent.
// Heuristic. It reports a confidence and the signals behind it, never a certainty.
(function () {
  const Roe = (self.Roe = self.Roe || {});

  // Pure scoring so it can be unit-tested. `sig` is a plain object of observed signals.
  Roe.scoreActor = function (sig) {
    if (sig.markedByUser) return { confidence: 1, signals: ['tab marked as agent-driven by the user'] };
    if (sig.treatAll) return { confidence: 1, signals: ['policy treats all activity as agent-driven'] };
    if (sig.inherit) return Roe.scoreActor(sig.inherit);
    let c = 0;
    const w = [];
    const add = (v, why) => { c += v; w.push(why); };
    if (sig.trusted === false) add(0.6, 'event was dispatched by a script, not input hardware');
    if (sig.webdriver) add(0.5, 'browser reports automation control');
    if (sig.pointerType !== 'touch') {
      if (sig.noPointerTravel) add(0.25, 'no pointer movement before the click');
      if (sig.centerClick) add(0.25, 'click landed on the exact center of the element');
    }
    if (sig.noDevice) add(0.3, 'no pointer or keyboard activity before the action');
    if (sig.burstTyping) add(0.4, 'machine-speed typing');
    if (sig.textWithoutKeys) add(0.3, 'text inserted without key events');
    return { confidence: Math.min(1, Math.round(c * 100) / 100), signals: w };
  };

  const st = { lastMove: -1e9, lastKey: -1e9, keyTimes: [], pointerType: 'mouse', lastClick: null };
  const now = () => performance.now();
  let started = false;

  function observe() {
    if (started) return;
    started = true;
    const o = { capture: true, passive: true };
    addEventListener('pointermove', () => { st.lastMove = now(); }, o);
    addEventListener('pointerdown', (e) => { st.pointerType = e.pointerType || 'mouse'; st.lastMove = now(); }, o);
    addEventListener('keydown', () => { const n = now(); st.lastKey = n; st.keyTimes.push(n); if (st.keyTimes.length > 8) st.keyTimes.shift(); }, o);
  }

  const api = (Roe.attribution = {
    observe,
    signals(e, el, kind) {
      const n = now();
      const base = { webdriver: !!navigator.webdriver || document.documentElement.hasAttribute('webdriver'), pointerType: e.pointerType || st.pointerType };
      if (kind === 'click') {
        const r = el.getBoundingClientRect();
        return {
          ...base,
          trusted: e.isTrusted,
          noPointerTravel: n - st.lastMove > 500,
          centerClick: r.width > 12 && r.height > 12 && Math.abs(e.clientX - (r.left + r.width / 2)) < 1.5 && Math.abs(e.clientY - (r.top + r.height / 2)) < 1.5,
          noDevice: e.detail === 0 && n - st.lastKey > 400
        };
      }
      if (kind === 'submit') {
        const recent = st.lastClick && n - st.lastClick.at < 800;
        return { ...base, noDevice: !recent && n - st.lastKey > 800, inherit: recent ? st.lastClick.sig : undefined };
      }
      const t = st.keyTimes;
      return {
        ...base,
        burstTyping: t.length >= 6 && t.slice(-6).every((x, i, a) => i === 0 || x - a[i - 1] < 12),
        textWithoutKeys: n - st.lastKey > 500
      };
    },
    recordClick(e) {
      const el = e.target instanceof Element ? e.target.closest('button,a,input,[role=button]') || e.target : null;
      if (el) st.lastClick = { at: now(), sig: api.signals(e, el, 'click') };
    }
  });
})();
