// Roe DLP. Detectors report only the TYPE of data found, never the data itself.
(function () {
  const Roe = (self.Roe = self.Roe || {});

  function luhn(d) {
    let sum = 0, alt = false;
    for (let i = d.length - 1; i >= 0; i--) {
      let n = d.charCodeAt(i) - 48;
      if (alt) { n *= 2; if (n > 9) n -= 9; }
      sum += n; alt = !alt;
    }
    return sum % 10 === 0;
  }

  const DETECTORS = {
    'aws-key': { label: 'AWS access key', test: (t) => /\b(AKIA|ASIA)[0-9A-Z]{16}\b/.test(t) },
    'private-key': { label: 'Private key', test: (t) => /-----BEGIN (RSA |EC |OPENSSH |DSA |PGP )?PRIVATE KEY( BLOCK)?-----/.test(t) },
    'github-token': { label: 'GitHub token', test: (t) => /\bgh[pousr]_[A-Za-z0-9]{36,}\b|\bgithub_pat_[A-Za-z0-9_]{50,}\b/.test(t) },
    'slack-token': { label: 'Slack token', test: (t) => /\bxox[baprs]-[A-Za-z0-9-]{10,}\b/.test(t) },
    'jwt': { label: 'JSON web token', test: (t) => /\beyJ[A-Za-z0-9_-]{8,}\.eyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\b/.test(t) },
    'secret-assignment': { label: 'Password or API key assignment', test: (t) => /\b(api[_-]?key|secret|passwd|password|token)\b\s*[:=]\s*['"]?[A-Za-z0-9_\-\/+=]{16,}/i.test(t) },
    'card': {
      label: 'Payment card number',
      test: (t) => (t.match(/\b(?:\d[ -]?){13,19}\b/g) || []).some((m) => { const d = m.replace(/\D/g, ''); return d.length >= 13 && d.length <= 19 && luhn(d); })
    },
    'ssn': { label: 'SSN-like number', test: (t) => /\b\d{3}-\d{2}-\d{4}\b/.test(t) }
  };

  Roe.dlpScan = function (text, enabled) {
    if (!text) return [];
    const t = text.length > 20000 ? text.slice(0, 20000) : text;
    const names = enabled && enabled.length ? enabled : Object.keys(DETECTORS);
    return names.filter((n) => DETECTORS[n] && DETECTORS[n].test(t)).map((n) => ({ type: n, label: DETECTORS[n].label }));
  };

  // Fast synchronous 53-bit hash (cyrb53) used to recognise text copied from a protected site.
  Roe.hash53 = function (str) {
    let h1 = 0xdeadbeef, h2 = 0x41c6ce57;
    for (let i = 0, ch; i < str.length; i++) {
      ch = str.charCodeAt(i);
      h1 = Math.imul(h1 ^ ch, 2654435761);
      h2 = Math.imul(h2 ^ ch, 1597334677);
    }
    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
    return 4294967296 * (2097151 & h2) + (h1 >>> 0);
  };
  Roe.normText = (t) => t.trim().replace(/\s+/g, ' ');

  // ---------- replication matching: does outbound text repeat a payload read earlier? ----------
  Roe.words = (t) => t.toLowerCase().normalize('NFKC').match(/[\p{L}\p{N}]+/gu) || [];
  // Hashes of overlapping k-word windows. Only hashes are kept, never the text.
  Roe.shingles = function (text, k) {
    k = k || 3;
    const w = Roe.words(String(text || ''));
    const out = new Set();
    for (let i = 0; i + k <= w.length && out.size < 200; i++) out.add(Roe.hash53(w.slice(i, i + k).join(' ')));
    return [...out];
  };
  // Share of the payload's shingles that also appear in `shingles` (0..1).
  Roe.containment = function (payload, shingles) {
    if (!payload || !payload.length || !shingles || !shingles.length) return 0;
    const s = new Set(shingles);
    let n = 0;
    for (const h of payload) if (s.has(h)) n++;
    return n / payload.length;
  };
})();
