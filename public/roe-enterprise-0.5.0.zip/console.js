// Roe console: device-level overview, incident timelines, tamper-evident audit log, edition and policy.
// All page-derived strings are shown with textContent only.
const $ = (s) => document.querySelector(s);
const el = (t, c, x) => { const n = document.createElement(t); if (c) n.className = c; if (x !== undefined) n.textContent = x; return n; };
const fmt = (ts) => new Date(ts).toLocaleString();
const clock = (ts) => new Date(ts).toLocaleTimeString();
const sha256 = async (s) => [...new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(s)))].map((x) => x.toString(16).padStart(2, '0')).join('');

async function state() {
  const [{ audit }, pol, s] = await Promise.all([
    chrome.storage.local.get({ audit: [] }),
    chrome.runtime.sendMessage({ type: 'roe:policy' }),
    chrome.storage.session.get(['quarantine', 'intent'])
  ]);
  return { audit, pol, enterprise: pol.tier === 'enterprise', quarantine: s.quarantine || null, intent: s.intent || null };
}
const tally = (arr) => { const m = new Map(); arr.filter(Boolean).forEach((k) => m.set(k, (m.get(k) || 0) + 1)); return [...m].sort((a, b) => b[1] - a[1]).slice(0, 6); };
function table(headers, rows) {
  const t = el('table'); const th = el('tr');
  headers.forEach((h) => th.append(el('th', '', h))); t.append(th);
  rows.forEach((r) => { const tr = el('tr'); r.forEach((c) => tr.append(el('td', '', String(c)))); t.append(tr); });
  if (!rows.length) { const tr = el('tr'); const td = el('td', '', 'Nothing yet'); td.colSpan = headers.length; tr.append(td); t.append(tr); }
  return t;
}
const isWorm = (e) => (e.flags || []).some((x) => x === 'outbound-injection' || x === 'payload-replication') || (e.rule || '').startsWith('worm-') || (e.action === 'fan-out' && /AI agents/.test(e.note || ''));
const isIncident = (e) => ['quarantine', 'tripwire'].includes(e.kind) || e.kind === 'anomaly' || isWorm(e) || ['intent-deviation', 'intent-deviation-tainted', 'carrier-writes'].includes(e.rule);

function banner({ quarantine, enterprise }) {
  const b = $('#banner'); b.replaceChildren();
  if (!enterprise || !quarantine) return;
  b.className = 'banner';
  b.append(el('strong', '', 'Agent session quarantined'), el('span', '', quarantine.reason.replace(/-/g, ' ') + (quarantine.detail ? ': ' + quarantine.detail : '') + ' (' + fmt(quarantine.at) + ')'));
  const r = el('button', 'act', 'Release quarantine');
  r.addEventListener('click', async () => { await chrome.runtime.sendMessage({ type: 'roe:release' }); refresh(); });
  b.append(r);
}

// ----- overview -----
function overview({ audit, pol, enterprise }) {
  const p = $('#overview'); p.replaceChildren();
  $('#who').textContent = enterprise
    ? (pol.managed ? 'Enterprise, managed by ' + (pol.policy.org || 'your organization') : 'Enterprise (developer preview)') + '. ' + (pol.policy.mode === 'enforce' ? 'Enforcing.' : 'Monitoring only.')
    : 'Free edition: detection and warnings. Enterprise controls are off.';
  const pages = audit.filter((e) => e.kind === 'page');
  const tiles = el('div', 'tiles');
  const tile = (k, v, c) => { const t = el('div', 'tile ' + (c || '')); t.append(el('b', '', v), el('span', '', k)); tiles.append(t); };
  tile('Pages with instructions aimed at agents', pages.length, 'bad');
  if (enterprise) {
    const act = audit.filter((e) => e.kind === 'action' && e.actor === 'agent');
    const by = (o) => act.filter((e) => e.outcome === o).length;
    tile('Agent actions', act.length); tile('Blocked', by('blocked'), 'bad'); tile('Approved', by('approved'), 'ok'); tile('Denied', by('denied'));
    tile('Quarantines', audit.filter((e) => e.kind === 'quarantine').length, 'bad');
    tile('Worm signals', audit.filter(isWorm).length, 'bad');
    tile('Tripwire hits', audit.filter((e) => e.kind === 'tripwire').length, 'bad');
    tile('Agent sessions', new Set(act.map((e) => e.session)).size);
  }
  p.append(tiles);
  const two = el('div', 'two');
  const a = el('div'); a.append(el('h2', '', 'Where instructions were found'), table(['Site', 'Pages'], tally(pages.map((e) => e.host))));
  const b = el('div'); b.append(el('h2', '', 'What kind of attack'), table(['Category', 'Times'], tally(pages.flatMap((e) => e.cats || []))));
  two.append(a, b); p.append(two);
  if (enterprise) {
    const act = audit.filter((e) => e.kind === 'action' && e.actor === 'agent');
    const t2 = el('div', 'two');
    const c = el('div'); c.append(el('h2', '', 'Where agents acted'), table(['Site', 'Actions'], tally(act.map((e) => e.host))));
    const d = el('div'); d.append(el('h2', '', 'Rules that fired'), table(['Rule', 'Times'], tally(act.map((e) => e.rule))));
    t2.append(c, d); p.append(t2);
  } else {
    p.append(el('p', 'msg', 'Enterprise adds agent attribution, policy, human approval, DLP, rogue-agent and worm detection, and a tamper-evident audit log.'));
  }
  p.append(el('p', 'cap', 'This view covers this browser only. A central dashboard across devices needs the backend, which is the next phase.'));
}

// ----- incidents: the chain from exposure to action -----
function incidents({ audit, enterprise }) {
  const p = $('#incidents'); p.replaceChildren();
  if (!enterprise) { p.append(el('div', 'note', 'Incident timelines are part of the enterprise edition.')); return; }
  const bySession = new Map();
  audit.forEach((e) => { if (e.session) { if (!bySession.has(e.session)) bySession.set(e.session, []); bySession.get(e.session).push(e); } });
  const hits = [...bySession].filter(([, evs]) => evs.some(isIncident)).sort((a, b) => b[1][b[1].length - 1].ts - a[1][a[1].length - 1].ts);
  if (!hits.length) { p.append(el('p', 'msg', 'No incidents. Quarantines, tripwire hits, worm-like writes, off-task actions and anomalies appear here with the chain that led to them.')); return; }
  hits.forEach(([sid, evs]) => {
    const t0 = evs[0].ts, t1 = evs[evs.length - 1].ts;
    const exposure = audit.filter((e) => e.kind === 'page' && e.ts >= t0 - 15 * 60000 && e.ts <= t1);
    const kinds = [];
    if (evs.some((e) => e.kind === 'tripwire')) kinds.push('tripwire hit');
    if (evs.some(isWorm)) kinds.push('worm-like behavior');
    if (evs.some((e) => e.rule && e.rule.startsWith('intent-deviation'))) kinds.push('acted outside the task');
    if (evs.some((e) => e.kind === 'quarantine' && e.action === 'retry-after-block')) kinds.push('retried after being blocked');
    if (evs.some((e) => e.rule === 'carrier-writes')) kinds.push('wrote to an instruction carrier');
    if (evs.some((e) => e.kind === 'anomaly')) kinds.push('anomaly');
    const card = el('div', 'incident');
    card.append(el('h3', '', kinds.length ? kinds[0][0].toUpperCase() + kinds.join(', ').slice(1) : 'Incident'), el('p', 'meta', 'Session ' + sid.slice(0, 14) + ', ' + fmt(t0) + ' to ' + clock(t1)));
    const ul = el('ul', 'chain');
    const rows = [...exposure.map((e) => ({ ts: e.ts, cls: 'exposure', head: 'Exposure', text: 'Instructions aimed at agents found on ' + e.host + (e.cats && e.cats.length ? ' (' + e.cats.join(', ') + ')' : '') })),
      ...evs.map((e) => {
        const bad = ['blocked', 'denied', 'tripwire', 'quarantined', 'flagged'].includes(e.outcome);
        let head = e.kind === 'action' ? 'Agent ' + e.action : e.kind === 'anomaly' ? 'Anomaly' : e.kind === 'quarantine' ? 'Quarantine' : e.kind === 'quarantine-release' ? 'Released by a person' : e.kind === 'tripwire' ? 'Tripwire' : e.kind;
        const parts = [e.label || e.note || '', e.host ? 'on ' + e.host : '', e.outcome ? '→ ' + e.outcome : '', e.rule ? '(' + e.rule + ')' : '', (e.flags || []).length ? '[' + e.flags.join(', ') + ']' : '', e.deviation ? e.deviation : ''].filter(Boolean);
        return { ts: e.ts, cls: bad ? 'bad' : e.outcome === 'released' || e.outcome === 'approved' ? 'ok' : '', head, text: parts.join(' ') };
      })].sort((a, b) => a.ts - b.ts);
    rows.forEach((r) => { const li = el('li'); li.append(el('span', 't', clock(r.ts))); const s = el('span', 'step ' + r.cls); s.append(el('b', '', r.head + ': '), document.createTextNode(r.text)); li.append(s); ul.append(li); });
    card.append(ul); p.append(card);
  });
}

// ----- audit -----
let auditState = { actor: 'all', outcome: 'all' };
function auditView({ audit, enterprise }) {
  const p = $('#audit'); p.replaceChildren();
  if (!enterprise) p.append(el('div', 'note', 'Free edition keeps a personal activity log of pages where instructions aimed at agents were found. Enterprise adds agent actions, decisions and the hash-chained audit trail.'));
  const bar = el('div', 'bar');
  const sel = (key, opts) => { const s = el('select'); opts.forEach((o) => { const op = el('option', '', o); op.value = o; s.append(op); }); s.value = auditState[key]; s.addEventListener('change', () => { auditState[key] = s.value; auditView({ audit, enterprise }); }); return s; };
  bar.append(el('span', '', 'Actor'), sel('actor', ['all', 'agent', 'human', 'system']), el('span', '', 'Outcome'), sel('outcome', ['all', 'allowed', 'blocked', 'approved', 'denied', 'monitored', 'flagged', 'quarantined', 'released', 'tripwire']));
  const verify = el('button', 'act', 'Verify log integrity'); const msg = el('span', 'msg');
  verify.addEventListener('click', async () => {
    let prev = null;
    for (let i = 0; i < audit.length; i++) {
      const { prev: pv, hash, ...rest } = audit[i];
      if ((await sha256(pv + JSON.stringify(rest))) !== hash) { msg.textContent = 'Entry ' + audit[i].seq + ' was modified.'; msg.className = 'msg err'; return; }
      if (i > 0 && pv !== prev) { msg.textContent = 'Entries are missing or reordered before ' + audit[i].seq + '.'; msg.className = 'msg err'; return; }
      prev = hash;
    }
    msg.textContent = audit.length + ' entries verified. Local tamper-evidence only; central collection is what makes it audit-grade.'; msg.className = 'msg good';
  });
  const exp = el('button', 'act', 'Export JSON');
  exp.addEventListener('click', () => { const a = el('a'); a.href = URL.createObjectURL(new Blob([JSON.stringify(audit, null, 2)], { type: 'application/json' })); a.download = 'roe-audit.json'; a.click(); });
  const clear = el('button', 'act', 'Clear log');
  clear.addEventListener('click', async () => { if (confirm('Clear the local log?')) { await chrome.storage.local.set({ audit: [], auditHead: 'genesis' }); refresh(); } });
  bar.append(verify, exp, clear, msg); p.append(bar);

  const rows = audit.filter((e) => (auditState.actor === 'all' || e.actor === auditState.actor) && (auditState.outcome === 'all' || e.outcome === auditState.outcome)).slice(-200).reverse();
  const t = el('table'); const hr = el('tr'); ['Time', 'Actor', 'Event', 'Site', 'Outcome', 'Rule'].forEach((h) => hr.append(el('th', '', h))); t.append(hr);
  rows.forEach((e) => {
    const tr = el('tr', 'clickable');
    [fmt(e.ts), e.actor + (e.confidence !== undefined ? ' (' + Math.round(e.confidence * 100) + '%)' : ''), (e.kind === 'action' ? e.action : e.kind + (e.action ? ': ' + e.action : '')) + (e.label ? ': ' + e.label : ''), e.host, e.outcome, e.rule || '']
      .forEach((c, i) => tr.append(el('td', i === 4 ? 'o-' + e.outcome : '', c)));
    const dr = el('tr'); dr.hidden = true;
    const dd = el('td', 'detail', JSON.stringify({ session: e.session, signals: e.signals, dlp: e.dlp, flags: e.flags, deviation: e.deviation, carrier: e.carrier, tainted: e.tainted, taintSource: e.taintSource, taintAge: e.taintAge, decision: e.decision, mode: e.mode, note: e.note, findings: e.findings, cats: e.cats, seq: e.seq, hash: e.hash }, null, 2));
    dd.colSpan = 6; dr.append(dd);
    tr.addEventListener('click', () => { dr.hidden = !dr.hidden; });
    t.append(tr, dr);
  });
  p.append(t);
  if (!rows.length) p.append(el('p', 'msg', 'No events yet.'));
}

// ----- edition and policy -----
function policyView({ pol, enterprise }) {
  const p = $('#policy'); p.replaceChildren();
  p.append(el('h2', '', 'Edition'));
  if (pol.managed) {
    p.append(el('div', 'note', 'Enterprise, delivered by your organization. The edition and policy cannot be changed here.'));
  } else {
    const ed = el('div', 'edition');
    [['free', 'Free'], ['enterprise', 'Enterprise (developer preview)']].forEach(([v, label]) => {
      const b = el('button', '', label); b.setAttribute('aria-pressed', String((v === 'enterprise') === enterprise));
      b.addEventListener('click', async () => { await chrome.storage.local.set({ tier: v }); refresh(); });
      ed.append(b);
    });
    p.append(ed, el('p', 'cap', 'This switch is for development and demos. In production the edition comes from a managed policy; a browser extension cannot enforce licensing on its own.'));
  }
  p.append(el('h2', '', 'Policy'));
  if (!enterprise) p.append(el('div', 'note', 'Policy applies in the enterprise edition. The free edition only detects and warns.'));
  const ta = el('textarea'); ta.value = JSON.stringify(pol.policy, null, 2); ta.disabled = pol.managed; ta.setAttribute('aria-label', 'Policy JSON');
  const msg = el('div', 'msg'); const bar = el('div', 'bar');
  const save = el('button', 'act', 'Save policy'); save.disabled = pol.managed;
  save.addEventListener('click', async () => {
    let parsed;
    try { parsed = JSON.parse(ta.value); } catch (e) { msg.textContent = 'Not valid JSON: ' + e.message; msg.className = 'msg err'; return; }
    const errs = Roe.validatePolicy(parsed);
    if (errs.length) { msg.textContent = errs.join('. '); msg.className = 'msg err'; return; }
    await chrome.storage.local.set({ devPolicy: parsed }); msg.textContent = 'Saved. Open tabs pick it up immediately.'; msg.className = 'msg good';
  });
  const reset = el('button', 'act', 'Reset to defaults'); reset.disabled = pol.managed;
  reset.addEventListener('click', async () => { await chrome.storage.local.remove('devPolicy'); refresh(); });
  bar.append(save, reset); p.append(bar, ta, msg);
}

async function refresh() { const s = await state(); banner(s); overview(s); incidents(s); auditView(s); policyView(s); }
document.querySelectorAll('nav button').forEach((b) => b.addEventListener('click', () => {
  document.querySelectorAll('nav button').forEach((x) => x.setAttribute('aria-selected', String(x === b)));
  document.querySelectorAll('main section').forEach((s) => { s.hidden = s.id !== b.dataset.tab; });
}));
refresh();
