// Roe service worker: collects each frame's report per tab, drives the toolbar badge,
// and (opt-in) fetches the raw Markdown an agent would read through the GitHub API.
importScripts('policy.js', 'dlp.js');
try { chrome.storage.session.setAccessLevel({ accessLevel: 'TRUSTED_AND_UNTRUSTED_CONTEXTS' }); } catch (e) { /* older Chrome */ }

const tabKey = (id) => 'tab:' + id;
let queue = Promise.resolve();
const enqueue = (fn) => (queue = queue.then(fn, fn));

function updateBadge(tabId, data) {
  let medium = 0, high = 0;
  for (const rep of Object.values(data.frames)) {
    for (const f of rep.findings) {
      if (f.gone) continue;
      if (f.level === 'high') high++;
      else if (f.level === 'medium') medium++;
    }
  }
  const n = high + medium;
  chrome.action.setBadgeText({ tabId, text: n ? String(n) : '' });
  chrome.action.setBadgeBackgroundColor({ tabId, color: high ? '#B00B3A' : '#9A5B00' });
}

// ---------- GitHub raw Markdown ----------
const GH_CACHE = new Map(); // key -> { at, items }
const NAME = /^[A-Za-z0-9_.-]{1,100}$/;
const trim = (s) => (typeof s === 'string' ? s.slice(0, 20000) : '');

async function githubRaw(t) {
  if (!t || !NAME.test(t.owner) || !NAME.test(t.repo) || (t.number && !/^\d{1,9}$/.test(t.number))) return { items: [], error: 'bad target' };
  const key = [t.owner, t.repo, t.kind, t.number || ''].join('/');
  const hit = GH_CACHE.get(key);
  if (hit && Date.now() - hit.at < 5 * 60 * 1000) return { items: hit.items };
  const base = 'https://api.github.com/repos/' + t.owner + '/' + t.repo;
  const opt = { headers: { Accept: 'application/vnd.github+json' }, credentials: 'omit' };
  const items = [];
  try {
    if (t.kind === 'repo') {
      const r = await fetch(base + '/readme', { headers: { Accept: 'application/vnd.github.raw+json' }, credentials: 'omit' });
      if (!r.ok) return { items, error: 'GitHub returned ' + r.status + ' (private repo or rate limit)' };
      items.push({ label: 'README', text: trim(await r.text()) });
    } else {
      const r = await fetch(base + '/issues/' + t.number, opt);
      if (!r.ok) return { items, error: 'GitHub returned ' + r.status + ' (private repo or rate limit)' };
      const j = await r.json();
      items.push({ label: (t.kind === 'pull' ? 'Pull request' : 'Issue') + ' description', text: trim(j.body) });
      const c = await fetch(base + '/issues/' + t.number + '/comments?per_page=50', opt);
      if (c.ok) (await c.json()).forEach((x, i) => items.push({ label: 'Comment ' + (i + 1) + ' by ' + (x.user && x.user.login), text: trim(x.body) }));
    }
  } catch (e) { return { items, error: 'network error' }; }
  GH_CACHE.set(key, { at: Date.now(), items });
  return { items };
}


// =====================================================================================
// Enterprise tier: org policy, agent sessions, quarantine, approvals and the audit log.
// Free tier keeps only a personal activity log of pages where instructions were found.
// =====================================================================================
function counts(data) {
  let medium = 0, high = 0;
  for (const rep of Object.values(data.frames)) for (const f of rep.findings) {
    if (f.gone) continue;
    if (f.level === 'high') high++; else if (f.level === 'medium') medium++;
  }
  return { medium, high };
}

// Policy: managed (MDM) first, then a local developer policy, then defaults.
// A managed policy means the enterprise tier; otherwise the tier is the local developer toggle.
async function loadPolicy() {
  try {
    const m = await chrome.storage.managed.get('policy');
    if (m && m.policy) {
      const parsed = typeof m.policy === 'string' ? JSON.parse(m.policy) : m.policy;
      return { policy: Roe.normalizePolicy(parsed), managed: true, tier: 'enterprise' };
    }
  } catch (e) { /* no managed policy, or invalid JSON: fall through */ }
  const { devPolicy, tier } = await chrome.storage.local.get(['devPolicy', 'tier']);
  return { policy: Roe.normalizePolicy(devPolicy), managed: false, tier: tier === 'enterprise' ? 'enterprise' : 'free' };
}

// ---------- agent session: ids, rate, site spread and fan-out ----------
async function touchSession(ev, policy, countAction) {
  const { agentSession } = await chrome.storage.session.get('agentSession');
  const now = Date.now();
  let s = agentSession;
  if (!(s && now - s.lastAt < 10 * 60000)) s = { id: 's-' + now.toString(36) + '-' + Math.random().toString(36).slice(2, 6), startedAt: now, lastAt: now, actions: 0, recent: [], hosts: [], fps: {}, flagged: {} };
  s.lastAt = now;
  const anomalies = [];
  if (countAction) {
    s.actions++;
    s.recent = s.recent.filter((t) => now - t < 60000);
    s.recent.push(now);
    if (ev.host && !s.hosts.includes(ev.host)) s.hosts.push(ev.host);
    const a = policy.anomaly;
    if (s.recent.length > a.maxActionsPer60s && !s.flagged.burst) { s.flagged.burst = 1; anomalies.push({ type: 'burst', detail: s.recent.length + ' agent actions in 60 seconds' }); }
    if (s.hosts.length > a.maxHostsPerSession && !s.flagged.hosts) { s.flagged.hosts = 1; anomalies.push({ type: 'host-spread', detail: 'Acted on ' + s.hosts.length + ' different sites in one session' }); }
    if (ev.fp) {
      let f = s.fps[ev.fp];
      if (!f || now - f.t0 > 10 * 60000) f = s.fps[ev.fp] = { n: 0, hosts: [], t0: now, worm: false, flagged: false };
      f.n++;
      if (!f.hosts.includes(ev.host)) f.hosts.push(ev.host);
      if ((ev.flags || []).some((x) => x === 'outbound-injection' || x === 'payload-replication')) f.worm = true;
      if (f.n >= a.fanOutThreshold && !f.flagged) {
        f.flagged = true;
        anomalies.push({ type: 'fan-out', worm: f.worm, detail: 'Same text sent ' + f.n + ' times to ' + f.hosts.length + ' site(s)' + (f.worm ? ', and it carries instructions aimed at AI agents' : '') });
      }
      const keys = Object.keys(s.fps);
      if (keys.length > 20) delete s.fps[keys[0]];
    }
  }
  await chrome.storage.session.set({ agentSession: s });
  return { id: s.id, anomalies };
}

// ---------- tamper-evident audit log (hash chain) ----------
const AUDIT_CAP = 2000;
const FIELDS = ['kind', 'host', 'page', 'actor', 'confidence', 'signals', 'action', 'label', 'decision', 'outcome', 'rule', 'tainted', 'taintSource', 'taintAge', 'dlp', 'flags', 'fp', 'deviation', 'carrier', 'mode', 'note', 'findings', 'cats'];
async function sha256hex(str) {
  const b = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(str));
  return [...new Uint8Array(b)].map((x) => x.toString(16).padStart(2, '0')).join('');
}
async function writeAudit(ev, extra) {
  const { audit = [], auditHead = 'genesis' } = await chrome.storage.local.get(['audit', 'auditHead']);
  const entry = { seq: (audit.length ? audit[audit.length - 1].seq : 0) + 1, ts: Date.now() };
  for (const k of FIELDS) if (ev[k] !== undefined) entry[k] = ev[k];
  if (extra) Object.assign(entry, extra);
  const hash = await sha256hex(auditHead + JSON.stringify(entry));
  audit.push({ ...entry, prev: auditHead, hash });
  if (audit.length > AUDIT_CAP) audit.splice(0, audit.length - AUDIT_CAP);
  await chrome.storage.local.set({ audit, auditHead: hash });
}
async function appendAudit(ev, sender) {
  const { policy, tier } = await loadPolicy();
  if (tier !== 'enterprise' && ev.kind !== 'page') return; // free tier: personal activity log only
  const extra = {};
  if (sender && sender.tab) extra.tabId = sender.tab.id;
  let anomalies = [];
  if (ev.actor === 'agent') {
    const s = await touchSession(ev, policy, ev.kind === 'action');
    extra.session = s.id;
    anomalies = s.anomalies;
  }
  await writeAudit(ev, extra);
  for (const a of anomalies) {
    await writeAudit({ kind: 'anomaly', host: ev.host, actor: 'system', action: a.type, outcome: 'flagged', note: a.detail }, { session: extra.session });
    if (a.type === 'fan-out' && a.worm && policy.quarantine.onWormFanOut) await setQuarantine('worm-fan-out', a.detail, ev.host, extra.session);
  }
}

// ---------- quarantine: every agent action is blocked until a human releases the session ----------
async function setQuarantine(reason, detail, host, session) {
  const { quarantine } = await chrome.storage.session.get('quarantine');
  if (quarantine) return false;
  await chrome.storage.session.set({ quarantine: { at: Date.now(), reason, detail, host, session } });
  await writeAudit({ kind: 'quarantine', host, actor: 'agent', action: reason, outcome: 'quarantined', note: detail }, session ? { session } : undefined);
  chrome.notifications.create('roe-q-' + Date.now(), { type: 'basic', iconUrl: 'icons/128.png', title: 'Roe quarantined an agent session',
    message: reason.replace(/-/g, ' ') + (detail ? ': ' + detail : '') + '. Open the Roe popup to review and release it.' });
  return true;
}

// ---------- taint and payload fingerprints after each page report ----------
async function afterReport(tabId, report, data, sender) {
  const c = counts(data);
  if (c.high + c.medium === 0) return;
  let source = '';
  try { source = new URL(report.url).host; } catch (e) { /* ignore */ }
  await chrome.storage.session.set({ taint: { at: Date.now(), source, level: c.high ? 'high' : 'medium', count: c.high + c.medium } });
  const sig = tabId + '|' + report.url + '|' + c.high + '|' + c.medium;
  const { lastPage } = await chrome.storage.session.get('lastPage');
  if (lastPage !== sig) {
    await chrome.storage.session.set({ lastPage: sig });
    const cats = [...new Set(Object.values(data.frames).flatMap((r) => r.findings.filter((f) => !f.gone && f.level !== 'low').flatMap((f) => f.cats || [])))];
    await appendAudit({ kind: 'page', host: source, actor: 'system', findings: c, cats, action: 'injection-found', outcome: 'flagged' }, sender);
  }
  const { policy, tier } = await loadPolicy();
  if (tier !== 'enterprise') return;
  // Word-window hashes of flagged passages (no text) let the gate notice an agent repeating a payload it read.
  const { payloads = [] } = await chrome.storage.session.get('payloads');
  const have = new Set(payloads.map((p) => p.id));
  for (const f of report.findings) {
    if (f.gone || f.level === 'low' || !f.snippet || have.has(f.id)) continue;
    const shingles = Roe.shingles(f.snippet, 3);
    if (shingles.length >= policy.worm.minShingles) { payloads.push({ id: f.id, source, shingles, at: Date.now() }); have.add(f.id); }
  }
  await chrome.storage.session.set({ payloads: payloads.slice(-20) });
}

// ---------- human approval in an extension window the page cannot draw over or script ----------
const pending = new Map();
function requestApproval(request) {
  return new Promise((resolve) => {
    const id = crypto.randomUUID();
    let done = false;
    const finish = (r) => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      const p = pending.get(id);
      pending.delete(id);
      if (p && p.windowId) chrome.windows.remove(p.windowId).catch(() => {});
      resolve(r);
    };
    const timer = setTimeout(() => finish({ approved: false, note: 'timed out' }), 120000);
    pending.set(id, { request, finish, windowId: null });
    chrome.windows.create({ url: chrome.runtime.getURL('approval.html?id=' + id), type: 'popup', width: 460, height: 700, focused: true })
      .then((w) => { const p = pending.get(id); if (p) p.windowId = w.id; })
      .catch(() => finish({ approved: false, note: 'could not open approval window' }));
  });
}
chrome.windows.onRemoved.addListener((windowId) => {
  for (const p of pending.values()) if (p.windowId === windowId) p.finish({ approved: false, note: 'window closed' });
});
const fromApprovalPage = (sender) => sender.id === chrome.runtime.id && typeof sender.url === 'string' && sender.url.startsWith(chrome.runtime.getURL('approval.html'));
const fromExtensionPage = (sender) => sender.id === chrome.runtime.id && typeof sender.url === 'string' && sender.url.startsWith(chrome.runtime.getURL(''));

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg) return false;
  if (msg.type === 'roe:report' && sender.tab) {
    const { id: tabId } = sender.tab;
    const frameId = sender.frameId;
    enqueue(async () => {
      const key = tabKey(tabId);
      const data = (await chrome.storage.session.get(key))[key] || { frames: {} };
      data.frames[frameId] = msg.report;
      await chrome.storage.session.set({ [key]: data });
      updateBadge(tabId, data);
      await afterReport(tabId, msg.report, data, sender);
    });
    return false;
  }
  if (msg.type === 'roe:get') {
    enqueue(async () => {
      const key = tabKey(msg.tabId);
      sendResponse((await chrome.storage.session.get(key))[key] || { frames: {} });
    });
    return true; // answer asynchronously
  }
  if (msg.type === 'roe:image' && sender.tab) {
    scanImageUrl(msg.url).then(sendResponse);
    return true;
  }
  if (msg.type === 'roe:github' && sender.tab) {
    githubRaw(msg.target).then(sendResponse);
    return true;
  }
  // ----- enterprise messages -----
  if (msg.type === 'roe:policy') { loadPolicy().then(sendResponse); return true; }
  if (msg.type === 'roe:whoami') { sendResponse({ tabId: sender.tab ? sender.tab.id : null }); return false; }
  if (msg.type === 'roe:audit') {
    if (sender.tab && msg.event) enqueue(() => appendAudit(msg.event, sender));
    return false;
  }
  if (msg.type === 'roe:quarantine') {
    if (!sender.tab) return false;
    enqueue(async () => {
      const { tier } = await loadPolicy();
      if (tier !== 'enterprise') return;
      const { agentSession } = await chrome.storage.session.get('agentSession');
      await setQuarantine(String(msg.reason || 'unknown').slice(0, 40), String(msg.detail || '').slice(0, 200), String(msg.host || '').slice(0, 100), agentSession && agentSession.id);
    });
    return false;
  }
  if (msg.type === 'roe:release') {
    if (!fromExtensionPage(sender)) return false;
    enqueue(async () => {
      const { quarantine } = await chrome.storage.session.get('quarantine');
      if (quarantine) {
        await chrome.storage.session.remove('quarantine');
        await writeAudit({ kind: 'quarantine-release', host: quarantine.host, actor: 'human', action: 'release', outcome: 'released', note: quarantine.reason });
      }
      sendResponse({ ok: true });
    });
    return true;
  }
  if (msg.type === 'roe:approve') {
    if (!sender.tab) return false;
    requestApproval(msg.request).then(sendResponse);
    return true;
  }
  if (msg.type === 'roe:approval-get') {
    if (!fromApprovalPage(sender)) return false;
    const p = pending.get(msg.id);
    sendResponse(p ? p.request : null);
    return false;
  }
  if (msg.type === 'roe:approval-resolve') {
    if (!fromApprovalPage(sender)) return false;
    const p = pending.get(msg.id);
    if (p) p.finish({ approved: !!msg.approved, note: String(msg.note || '').slice(0, 200) });
    sendResponse({ ok: !!p });
    return false;
  }
  return false;
});

// A new page load starts a fresh report.
chrome.tabs.onUpdated.addListener((tabId, info) => {
  if (info.status === 'loading') enqueue(() => chrome.storage.session.remove(tabKey(tabId)));
});
chrome.tabs.onRemoved.addListener((tabId) => enqueue(async () => {
  await chrome.storage.session.remove(tabKey(tabId));
  const { agentTabs = {} } = await chrome.storage.session.get('agentTabs');
  if (agentTabs[tabId]) { delete agentTabs[tabId]; await chrome.storage.session.set({ agentTabs }); }
}));

// ---------- offscreen scanner (documents and images need a DOM) ----------
let offPromise = null;
function ensureOffscreen() {
  if (offPromise) return offPromise;
  offPromise = (async () => {
    const ctxs = await chrome.runtime.getContexts({ contextTypes: ['OFFSCREEN_DOCUMENT'] });
    if (!ctxs.length) await chrome.offscreen.createDocument({ url: 'offscreen.html', reasons: ['DOM_PARSER', 'BLOBS'], justification: 'Parse documents and decode images to look for hidden instructions aimed at AI agents.' });
  })().catch((e) => { offPromise = null; throw e; });
  return offPromise;
}
async function offScan(url, name, max) {
  await ensureOffscreen();
  try { return await chrome.runtime.sendMessage({ type: 'roe:off-scan', url, name, max }); }
  catch (e) { offPromise = null; await ensureOffscreen(); return chrome.runtime.sendMessage({ type: 'roe:off-scan', url, name, max }); }
}

// ---------- images on pages ----------
const IMG_CACHE = new Map();
const EXT = { 'image/png': 'png', 'image/jpeg': 'jpg', 'image/gif': 'gif', 'image/webp': 'webp', 'image/svg+xml': 'svg' };
function imageName(url) {
  if (url.startsWith('data:')) return 'image.' + (EXT[(/^data:([^;,]+)/.exec(url) || [])[1]] || 'png');
  try { const n = new URL(url).pathname.split('/').pop() || 'image'; return /\.(png|jpe?g|gif|webp|svg)$/i.test(n) ? n : n + '.img'; } catch (e) { return 'image.img'; }
}
async function scanImageUrl(url) {
  if (!/^(https?:|data:image\/)/.test(url)) return { ok: false, error: 'unsupported' };
  if (IMG_CACHE.has(url)) return IMG_CACHE.get(url);
  const res = await offScan(url, imageName(url), 8 * 1024 * 1024).catch((e) => ({ ok: false, error: String(e) }));
  if (IMG_CACHE.size > 200) IMG_CACHE.delete(IMG_CACHE.keys().next().value);
  IMG_CACHE.set(url, res);
  return res;
}

// ---------- downloads ----------
const SKIP_DL = /\.(mp[34]|m4a|mov|avi|mkv|webm|iso|dmg|exe|msi|apk|deb|rpm|torrent|woff2?|ttf|otf)$/i;
const fileUrl = (p) => (p.startsWith('/') ? 'file://' + encodeURI(p) : 'file:///' + encodeURI(p.replace(/\\/g, '/')));
async function scanDownload(item) {
  const name = item.filename.split(/[\\/]/).pop();
  const rec = { id: item.id, name, at: Date.now(), kind: '', findings: [], notes: [], error: '' };
  try {
    const r = await offScan(fileUrl(item.filename), name, 40 * 1024 * 1024);
    if (!r || !r.ok) rec.error = /Failed to fetch|NetworkError/i.test((r && r.error) || '') ? 'file-access' : ((r && r.error) || 'unreadable');
    else { rec.kind = r.res.kind; rec.notes = r.res.notes.slice(0, 6); rec.findings = r.res.findings.slice(0, 25); }
  } catch (e) { rec.error = 'unreadable'; }
  const { downloadScans = [] } = await chrome.storage.local.get('downloadScans');
  await chrome.storage.local.set({ downloadScans: [rec, ...downloadScans.filter((x) => x.id !== rec.id)].slice(0, 25) });
  const strong = rec.findings.filter((f) => f.level !== 'low').length;
  if (strong) {
    chrome.notifications.create('roe-dl-' + rec.id, { type: 'basic', iconUrl: 'icons/128.png', title: 'Roe: instructions aimed at AI agents in a download',
      message: name + ': ' + strong + (strong === 1 ? ' possible attack' : ' possible attacks') + '. Click to see what an agent would read.' });
  }
  return rec;
}
async function onDownloadChanged(delta) {
  if (!delta.state || delta.state.current !== 'complete') return;
  const s = await chrome.storage.local.get({ scanDownloads: true });
  if (!s.scanDownloads) return;
  const [item] = await chrome.downloads.search({ id: delta.id });
  if (!item || !item.filename || SKIP_DL.test(item.filename) || item.fileSize > 40 * 1024 * 1024) return;
  let rec = await scanDownload(item);
  if (rec.error && rec.error !== 'file-access') { await new Promise((r) => setTimeout(r, 1500)); rec = await scanDownload(item); }   // one retry for transient failures
}
chrome.downloads.onChanged.addListener((delta) => { onDownloadChanged(delta).catch((e) => console.warn('Roe: download scan failed', e)); });
chrome.notifications.onClicked.addListener((id) => {
  const m = /^roe-dl-(\d+)$/.exec(id);
  if (m) { chrome.tabs.create({ url: chrome.runtime.getURL('scan.html#dl=' + m[1]) }); chrome.notifications.clear(id); }
});
